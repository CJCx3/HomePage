#!/usr/bin/env python
"""Start the trading runner. Mode comes from config.yaml.

  * paper (default): real-time data, SIMULATED orders on Alpaca's paper endpoint.
  * live: REAL money — refuses to start unless BOTH `mode: live` and
    `i_understand_live_risk: true` are set in config.yaml.

Examples
--------
  python scripts/run_live.py                 # run until Ctrl-C
  python scripts/run_live.py --iterations 2  # short session (e.g. a demo), then stop
"""

from __future__ import annotations

import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from dotenv import load_dotenv

load_dotenv()

from src.config import ConfigError, load_config
from src.execution.broker import BrokerError
from src.live.runner import LiveRunner


def main() -> int:
    ap = argparse.ArgumentParser(description="Run the daytrader loop (paper/live per config).")
    ap.add_argument("--iterations", type=int, default=None,
                    help="run this many cycles then stop (default: run until Ctrl-C)")
    ap.add_argument("--poll-seconds", type=float, default=None,
                    help="override the inter-cycle sleep (default: time to next bar close)")
    ap.add_argument("--until-close", action="store_true",
                    help="session mode: wait for the open, trade every bar, stop at the close "
                         "(run a full trading day)")
    ap.add_argument("--max-runtime-hours", type=float, default=9.0,
                    help="hard backstop; the runner always stops after this many hours")
    ap.add_argument("--config", default=None)
    args = ap.parse_args()

    try:
        # load_config enforces the live-risk gate and exits with a clear message.
        config = load_config(args.config)
    except ConfigError as e:
        print(f"\nCONFIG ERROR:\n{e}\n", file=sys.stderr)
        return 2

    key = os.getenv("ALPACA_API_KEY")
    secret = os.getenv("ALPACA_SECRET_KEY")
    if not key or not secret or key == "your_key_here":
        print("\nMISSING ALPACA KEYS.\n"
              "  Paper mode (the default) still needs Alpaca PAPER keys for real-time data\n"
              "  and simulated orders. Copy .env.example -> .env and paste your keys.\n"
              "  Get free paper keys at https://alpaca.markets (Paper account view).\n",
              file=sys.stderr)
        return 3

    if config.is_live:
        print("\n*** LIVE MODE — REAL MONEY. Orders will hit your live Alpaca account. ***")
        print("*** Ctrl-C now if this is not what you intend. ***\n")

    try:
        runner = LiveRunner(config, key, secret)
        stats = runner.run(max_iterations=args.iterations, poll_seconds=args.poll_seconds,
                           until_close=args.until_close, max_runtime_hours=args.max_runtime_hours)
    except BrokerError as e:
        print(f"\nBROKER ERROR: {e}\n", file=sys.stderr)
        return 4

    print(f"\nSession summary: {stats.iterations} cycle(s), "
          f"{stats.orders_submitted} order(s) submitted "
          f"(buys={stats.buys}, sells={stats.sells}), "
          f"strategy swaps={stats.strategy_swaps}, "
          f"kill switch tripped={stats.killswitch_tripped}.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
