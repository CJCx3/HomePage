#!/usr/bin/env python
"""Clear a tripped max-daily-loss kill switch.

The kill switch persists across restarts and does NOT auto-clear the next day —
you must acknowledge it here. This does not place any orders; it only clears the
`tripped` flag so the runner may trade again on its next cycle.
"""

from __future__ import annotations

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.config import ConfigError, load_config
from src.risk.controls import RiskManager


def main() -> int:
    try:
        config = load_config()
    except ConfigError as e:
        print(f"CONFIG ERROR:\n{e}", file=sys.stderr)
        return 2

    rm = RiskManager(config)
    if not rm.is_tripped():
        print("Kill switch is NOT tripped. Nothing to reset.")
        if rm.state.starting_equity is not None:
            print(f"(session baseline equity = {rm.state.starting_equity:.2f}, "
                  f"date = {rm.state.session_date})")
        return 0

    print("Kill switch is TRIPPED:")
    print(f"  when   : {rm.state.tripped_at}")
    print(f"  reason : {rm.state.tripped_reason}")
    rm.reset()
    print("\nKill switch RESET. The runner may resume trading on its next cycle.")
    print("Before restarting, confirm your broker positions are what you expect.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
