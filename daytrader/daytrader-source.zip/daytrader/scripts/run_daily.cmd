@echo off
REM ============================================================
REM  DAILY SWING decision (paper). Runs once near the market
REM  close: reads the last COMPLETED daily bar, reconciles the
REM  position (ma_crossover 10/80), and exits. The position is
REM  HELD OVERNIGHT (eod_flat = false). A few retries guard
REM  against a transient empty data pull.
REM  Logs to reports\scheduled_daily.log (+ reports\live_YYYYMMDD.log).
REM ============================================================
cd /d "%~dp0.."
echo. >> "reports\scheduled_daily.log"
echo ==== daily swing decision %DATE% %TIME% ==== >> "reports\scheduled_daily.log"
"venv\Scripts\python.exe" "scripts\run_live.py" --iterations 3 --poll-seconds 15 >> "reports\scheduled_daily.log" 2>&1
echo ==== done %DATE% %TIME% (exit %ERRORLEVEL%) ==== >> "reports\scheduled_daily.log"
