@echo off
REM ============================================================
REM  Launch daytrader for a FULL PAPER TRADING DAY.
REM  Session mode: waits for the market open, trades every bar,
REM  and stops at the close. Used by the scheduled task.
REM  All output is appended to reports\scheduled_paper_run.log
REM  (the runner also writes reports\live_YYYYMMDD.log).
REM ============================================================
cd /d "%~dp0.."
echo. >> "reports\scheduled_paper_run.log"
echo ==== scheduled paper run started %DATE% %TIME% ==== >> "reports\scheduled_paper_run.log"
"venv\Scripts\python.exe" "scripts\run_live.py" --until-close --max-runtime-hours 8 >> "reports\scheduled_paper_run.log" 2>&1
echo ==== scheduled paper run ended %DATE% %TIME% (exit %ERRORLEVEL%) ==== >> "reports\scheduled_paper_run.log"
