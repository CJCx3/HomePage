#!/usr/bin/env python
"""Backtest ONE strategy over history and write an equity-curve PNG vs buy-and-hold.

Examples
--------
  # key-free daily backtest on yfinance (works with no Alpaca account):
  python scripts/run_backtest.py --strategy ma_crossover --source yfinance --resolution 1Day --start 2018-01-01

  # intraday backtest using the resolution/source from config.yaml:
  python scripts/run_backtest.py --strategy breakout
"""

from __future__ import annotations

import argparse
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from dotenv import load_dotenv

load_dotenv()

from src.backtest.engine import run_backtest
from src.backtest.metrics import compute_metrics
from src.config import ConfigError, load_config
from src.data.loader import DataError, load_bars
from src.logging_util import PROJECT_ROOT
from src.reporting.report import save_equity_curve_png
from src.strategies.registry import ACTIVE_STRATEGY_NAMES, build_strategy
from src.strategies.buy_and_hold import BuyAndHold
from src.timeframes import parse_resolution


def main() -> int:
    ap = argparse.ArgumentParser(description="Backtest one strategy vs buy-and-hold.")
    ap.add_argument("--strategy", default="ma_crossover",
                    choices=ACTIVE_STRATEGY_NAMES + ["buy_and_hold"])
    ap.add_argument("--symbol")
    ap.add_argument("--resolution", help="e.g. 1Day, 5Min (default: config)")
    ap.add_argument("--source", choices=["yfinance", "alpaca"], help="default: config")
    ap.add_argument("--start", help="YYYY-MM-DD (daily only)")
    ap.add_argument("--end", help="YYYY-MM-DD")
    ap.add_argument("--lookback-days", type=int, help="intraday recent window")
    ap.add_argument("--cash", type=float)
    ap.add_argument("--slippage-bps", type=float)
    ap.add_argument("--commission", type=float)
    ap.add_argument("--params", help='JSON override, e.g. \'{"fast":10,"slow":30}\'')
    ap.add_argument("--config", default=None)
    args = ap.parse_args()

    try:
        config = load_config(args.config)
    except ConfigError as e:
        print(f"CONFIG ERROR:\n{e}", file=sys.stderr)
        return 2

    symbol = (args.symbol or config.symbol).upper()
    resolution = args.resolution or config.bar_resolution
    source = args.source or config.data.source
    cash = args.cash if args.cash is not None else config.backtest.starting_cash
    slippage = args.slippage_bps if args.slippage_bps is not None else config.backtest.slippage_bps
    commission = args.commission if args.commission is not None else config.backtest.commission_per_trade
    lookback = args.lookback_days or config.data.lookback_days
    start = args.start if args.start is not None else config.data.start
    end = args.end if args.end is not None else config.data.end

    # strategy params: config defaults unless overridden on the CLI
    if args.strategy == "buy_and_hold":
        params = {}
    else:
        params = getattr(config.strategies, args.strategy).model_dump()
        if args.params:
            params.update(json.loads(args.params))

    print(f"Backtest: {args.strategy}{params} on {symbol} @ {resolution} "
          f"[{source}]  cash=${cash:,.0f} slippage={slippage}bps commission=${commission}")

    try:
        bars = load_bars(symbol, resolution, source=source, start=start, end=end,
                         lookback_days=lookback,
                         key=os.getenv("ALPACA_API_KEY"), secret=os.getenv("ALPACA_SECRET_KEY"),
                         min_bars=30)
    except DataError as e:
        print(f"DATA ERROR: {e}", file=sys.stderr)
        return 3

    strat = build_strategy(args.strategy, params)
    bench = BuyAndHold()
    ppy = parse_resolution(resolution).periods_per_year

    strat_res = run_backtest(bars, strat.generate_signals(bars), cash, commission, slippage)
    bench_res = run_backtest(bars, bench.generate_signals(bars), cash, commission, slippage)

    strat_m = compute_metrics(strat_res.equity_curve, strat_res.round_trips, ppy, strat_res.exposure_fraction)
    bench_m = compute_metrics(bench_res.equity_curve, bench_res.round_trips, ppy, bench_res.exposure_fraction)

    # Also run a zero-cost version to SHOW that costs reduce returns.
    zc_res = run_backtest(bars, strat.generate_signals(bars), cash, 0.0, 0.0)
    zc_final = zc_res.equity_curve.iloc[-1]

    print("\n" + "=" * 70)
    print(f"  {args.strategy}  (with costs)")
    print(f"    {strat_m.summary_line()}")
    print(f"    final equity = ${strat_m.final_equity:,.2f}")
    print(f"  buy_and_hold (benchmark)")
    print(f"    {bench_m.summary_line()}")
    print(f"    final equity = ${bench_m.final_equity:,.2f}")
    print("-" * 70)
    print(f"  cost impact: zero-cost final ${zc_final:,.2f} vs with-cost "
          f"${strat_m.final_equity:,.2f}  (costs took ${zc_final - strat_m.final_equity:,.2f})")
    beat = "YES" if strat_m.total_return > bench_m.total_return else "NO"
    print(f"  beat buy-and-hold on total return? {beat}")
    print("=" * 70)

    reports = PROJECT_ROOT / "reports"
    png = reports / f"backtest_{args.strategy}_{symbol}_{resolution}.png"
    save_equity_curve_png(
        strat_res.equity_curve, bench_res.equity_curve,
        title=f"{args.strategy} vs buy-and-hold — {symbol} @ {resolution} (costs modeled)",
        out_path=png, strategy_label=args.strategy,
    )
    print(f"\nEquity curve PNG written: {png}")
    print("Reminder: a good backtest is NOT a prediction. Costs are modeled above.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
