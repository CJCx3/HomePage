#!/usr/bin/env python
"""Rank all candidate strategies out-of-sample and (if one wins) write it to
active_strategy.json.

Prints the full report and — importantly — headlines "NO EDGE FOUND" when no
strategy beats buy-and-hold out-of-sample. That is a valid, honest result.

Examples
--------
  # key-free daily selection on yfinance:
  python scripts/run_selection.py --source yfinance --resolution 1Day --start 2018-01-01

  # intraday selection using config.yaml (needs Alpaca keys):
  python scripts/run_selection.py
"""

from __future__ import annotations

import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from dotenv import load_dotenv

load_dotenv()

from src.active_strategy import write_active
from src.config import ConfigError, load_config
from src.data.loader import DataError, load_bars
from src.reporting.report import format_selection_report, write_selection_report
from src.selection.selector import run_selection


def main() -> int:
    ap = argparse.ArgumentParser(description="Rank candidates OOS; promote a winner or report NO EDGE FOUND.")
    ap.add_argument("--symbol")
    ap.add_argument("--resolution")
    ap.add_argument("--source", choices=["yfinance", "alpaca"])
    ap.add_argument("--start")
    ap.add_argument("--end")
    ap.add_argument("--lookback-days", type=int)
    ap.add_argument("--no-write", action="store_true",
                    help="rank and report but do NOT modify active_strategy.json")
    ap.add_argument("--config", default=None)
    args = ap.parse_args()

    try:
        config = load_config(args.config)
    except ConfigError as e:
        print(f"CONFIG ERROR:\n{e}", file=sys.stderr)
        return 2

    # Apply optional overrides onto a copy so selection stays resolution-coherent.
    if args.symbol:
        config.symbol = args.symbol.upper()
    if args.resolution:
        config.bar_resolution = args.resolution
    if args.source:
        config.data.source = args.source
    if args.lookback_days:
        config.data.lookback_days = args.lookback_days
    start = args.start if args.start is not None else config.data.start
    end = args.end if args.end is not None else config.data.end

    print(f"Selection: {config.symbol} @ {config.bar_resolution} [{config.data.source}] "
          f"train_frac={config.selection.train_frac} min_trades={config.selection.min_trades} "
          f"metric=OOS-{config.selection.ranking_metric}"
          + ("  [walk-forward]" if config.selection.walk_forward else ""))

    try:
        bars = load_bars(
            config.symbol, config.bar_resolution, source=config.data.source,
            start=start, end=end, lookback_days=config.data.lookback_days,
            key=os.getenv("ALPACA_API_KEY"), secret=os.getenv("ALPACA_SECRET_KEY"),
            min_bars=60,
        )
    except DataError as e:
        print(f"DATA ERROR: {e}", file=sys.stderr)
        return 3

    report = run_selection(config, bars)

    print("\n" + format_selection_report(report))
    out = write_selection_report(report)
    print(f"\nReport written: {out}")

    if report.winner and not args.no_write:
        write_active(
            report.winner, report.winner_params, set_by="auto-reselect",
            note=f"Auto-selected: best OOS {report.ranking_metric} that beat buy-and-hold.",
        )
        print(f"active_strategy.json updated -> {report.winner} {report.winner_params}")
    elif report.no_edge:
        print("NO EDGE FOUND — active_strategy.json left UNCHANGED (nothing promoted).")
    elif args.no_write:
        print("(--no-write) active_strategy.json left unchanged.")

    # exit 0 always: NO EDGE FOUND is a valid outcome, not an error.
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
