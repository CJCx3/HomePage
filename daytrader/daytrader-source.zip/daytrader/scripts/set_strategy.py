#!/usr/bin/env python
"""Manually set the active strategy. Takes effect on the runner's NEXT cycle —
no restart needed (the runner hot-reloads active_strategy.json every loop).

Examples
--------
  python scripts/set_strategy.py ma_crossover --params '{"fast":9,"slow":21}'
  python scripts/set_strategy.py rsi_reversion --set period=14 --set oversold=25 --set exit_level=55
  python scripts/set_strategy.py buy_and_hold
"""

from __future__ import annotations

import argparse
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.active_strategy import ACTIVE_PATH, write_active
from src.strategies.registry import STRATEGIES


def _coerce(v: str):
    for cast in (int, float):
        try:
            return cast(v)
        except ValueError:
            continue
    if v.lower() in ("true", "false"):
        return v.lower() == "true"
    return v


def main() -> int:
    ap = argparse.ArgumentParser(description="Set active_strategy.json (hot-reloaded next cycle).")
    ap.add_argument("name", choices=sorted(STRATEGIES.keys()))
    ap.add_argument("--params", help='full JSON params, e.g. \'{"fast":9,"slow":21}\'')
    ap.add_argument("--set", action="append", default=[], metavar="key=value",
                    help="set a single param (repeatable), e.g. --set fast=9")
    ap.add_argument("--note", default="")
    args = ap.parse_args()

    params: dict = {}
    if args.params:
        params.update(json.loads(args.params))
    for pair in args.set:
        if "=" not in pair:
            print(f"bad --set {pair!r}; expected key=value", file=sys.stderr)
            return 2
        k, v = pair.split("=", 1)
        params[k] = _coerce(v)

    try:
        write_active(args.name, params, set_by="manual", note=args.note)
    except (TypeError, ValueError, KeyError) as e:
        print(f"INVALID strategy/params: {e}", file=sys.stderr)
        return 2

    print(f"active strategy set -> {args.name} {params}")
    print(f"written to {ACTIVE_PATH}")
    print("The running bot (if any) will pick this up on its next cycle — no restart needed.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
