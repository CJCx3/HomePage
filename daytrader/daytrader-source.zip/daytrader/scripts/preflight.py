#!/usr/bin/env python
"""Preflight — run this FIRST, before trading.

Prints PASS / WARN / FAIL for seven checks and exits non-zero if ANY check
FAILs. WARN never fails the run (e.g. a thin intraday feed is a caution, not a
blocker). See build pack section I.

  1. Python >= 3.11
  2. All requirements.txt packages import
  3. .env present + keys load + a real TradingClient.get_account() on the
     correct paper/live endpoint for `mode`
  4. config.yaml validates; if mode: live then i_understand_live_risk must be true
  5. Historical fetch for symbol @ bar_resolution returns >= warmup bars (warn if thin)
  6. Market clock fetched; prints open/closed + next open/close
  7. active_strategy.json exists and names a known strategy with valid params
"""

from __future__ import annotations

import os
import sys
from zoneinfo import ZoneInfo

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from dotenv import load_dotenv

load_dotenv()

NY = ZoneInfo("America/New_York")

PASS, WARN, FAIL = "PASS", "WARN", "FAIL"
_results: list[tuple[str, str, str]] = []


def record(check: str, status: str, detail: str = "") -> None:
    _results.append((check, status, detail))
    line = f"  [{status}] {check}"
    if detail:
        line += f"\n         {detail}"
    print(line)


def main() -> int:
    print("=" * 72)
    print("  daytrader preflight")
    print("=" * 72)

    # 1) Python >= 3.11
    v = sys.version_info
    if (v.major, v.minor) >= (3, 11):
        record("1. Python >= 3.11", PASS, f"running {v.major}.{v.minor}.{v.micro}")
    else:
        record("1. Python >= 3.11", FAIL, f"found {v.major}.{v.minor}; upgrade to 3.11+")

    # 2) requirements import
    pkgs = {
        "alpaca-py": "alpaca", "yfinance": "yfinance", "pandas": "pandas",
        "numpy": "numpy", "matplotlib": "matplotlib", "pyyaml": "yaml",
        "pydantic": "pydantic", "python-dotenv": "dotenv", "pytest": "pytest",
    }
    missing = []
    for dist, mod in pkgs.items():
        try:
            __import__(mod)
        except Exception:
            missing.append(dist)
    if missing:
        record("2. requirements import", FAIL,
               f"missing/broken: {', '.join(missing)}  (pip install -r requirements.txt)")
    else:
        record("2. requirements import", PASS, "all core packages import")

    # 4) config validates (run before 3 because 3 needs mode/endpoint)
    from src.config import ConfigError, load_config
    config = None
    try:
        config = load_config()
        record("4. config.yaml validates", PASS,
               f"mode={config.mode}, symbol={config.symbol}, resolution={config.bar_resolution}")
    except ConfigError as e:
        first = str(e).strip().splitlines()[0]
        record("4. config.yaml validates", FAIL, first)

    # 7) active_strategy.json
    from src.active_strategy import ActiveStrategyError, build_active
    try:
        strat, data = build_active()
        record("7. active_strategy.json", PASS,
               f"{data['name']} {data.get('params')} (warmup={strat.warmup} bars)")
    except ActiveStrategyError as e:
        strat = None
        record("7. active_strategy.json", FAIL, str(e).splitlines()[0])

    key = os.getenv("ALPACA_API_KEY")
    secret = os.getenv("ALPACA_SECRET_KEY")
    have_env = os.path.exists(os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))), ".env"))
    keys_ok = bool(key and secret and key != "your_key_here")

    # 3) .env + keys + live account call
    broker = None
    if config is None:
        record("3. broker connectivity", FAIL, "cannot check — config invalid")
    elif config.data.source == "yfinance" and config.mode in ("backtest", "select") and not keys_ok:
        record("3. broker connectivity", WARN,
               "no keys, but mode is offline research (yfinance) — keys only needed for paper/live")
    elif not keys_ok:
        hint = "no .env file found" if not have_env else "keys missing or still 'your_key_here'"
        record("3. broker connectivity", FAIL,
               f"{hint}. Copy .env.example -> .env and paste your Alpaca "
               f"{'PAPER' if not config.is_live else 'LIVE'} keys.")
    else:
        try:
            from src.execution.broker import Broker
            broker = Broker(config.broker_mode, key, secret)
            acct = broker.get_account()
            record("3. broker connectivity", PASS,
                   f"{config.broker_mode.upper()} endpoint OK — equity=${acct.equity:,.2f} "
                   f"cash=${acct.cash:,.2f}")
        except Exception as e:
            record("3. broker connectivity", FAIL,
                   f"{config.broker_mode.upper()} get_account() failed: {str(e).splitlines()[0]}")

    # 5) historical fetch >= warmup
    if config is None or strat is None:
        record("5. historical data >= warmup", FAIL, "cannot check — config/strategy invalid")
    else:
        from src.strategies.registry import build_candidates
        warmup = max(s.warmup for s in build_candidates(config))
        try:
            from src.data.loader import DataError, load_bars
            bars = load_bars(
                config.symbol, config.bar_resolution, source=config.data.source,
                start=config.data.start, end=config.data.end,
                lookback_days=config.data.lookback_days,
                key=key, secret=secret, min_bars=1,
            )
            n = len(bars)
            if n < warmup:
                record("5. historical data >= warmup", FAIL,
                       f"only {n} bars < warmup {warmup}. Widen the window or use bar_resolution: 1Day.")
            else:
                # crude thinness heuristic for intraday IEX
                detail = f"{n} bars fetched (need >= {warmup})"
                if config.resolution.is_intraday and n < warmup * 3:
                    record("5. historical data >= warmup", WARN,
                           detail + " — feed looks THIN (free IEX ~2.5% volume). "
                                    "Consider bar_resolution: 1Day.")
                else:
                    record("5. historical data >= warmup", PASS, detail)
        except DataError as e:
            record("5. historical data >= warmup", FAIL, str(e).splitlines()[0])
        except Exception as e:
            record("5. historical data >= warmup", FAIL, str(e).splitlines()[0])

    # 6) market clock
    if broker is not None:
        try:
            clock = broker.get_clock()
            state = "OPEN" if clock.is_open else "CLOSED"
            no = clock.next_open.astimezone(NY).strftime("%Y-%m-%d %H:%M %Z")
            nc = clock.next_close.astimezone(NY).strftime("%Y-%m-%d %H:%M %Z")
            record("6. market clock", PASS,
                   f"market is {state} | next open {no} | next close {nc}")
        except Exception as e:
            record("6. market clock", FAIL, str(e).splitlines()[0])
    elif config is not None and config.mode in ("backtest", "select"):
        record("6. market clock", WARN, "skipped — offline research mode (no broker session)")
    else:
        record("6. market clock", FAIL, "cannot check — no broker session")

    # -- summary --
    fails = sum(1 for _, s, _ in _results if s == FAIL)
    warns = sum(1 for _, s, _ in _results if s == WARN)
    print("=" * 72)
    if fails:
        print(f"  RESULT: {fails} FAIL, {warns} WARN — fix the FAILs before trading.")
    else:
        print(f"  RESULT: all checks passed ({warns} warning(s)). You're clear to run.")
    print("=" * 72)
    return 1 if fails else 0


if __name__ == "__main__":
    raise SystemExit(main())
