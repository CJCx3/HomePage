"""Auto-selection: rank candidates out-of-sample, honestly.

Procedure (spec section 7):
  1. Split the timeline by DATE: first `train_frac` = in-sample (IS), rest =
     out-of-sample (OOS).
  2. Backtest every candidate (incl. buy-and-hold) on IS and OOS separately,
     with full costs.
  3. Disqualify any ACTIVE strategy with fewer than `min_trades` OOS trades.
     Buy-and-hold is the benchmark and is exempt (it trades once by design).
  4. Rank survivors by their OOS `ranking_metric` (default OOS Sharpe).
  5. Compare the winner to buy-and-hold on OOS net of costs. If it does not
     beat the benchmark -> headline "NO EDGE FOUND" and promote NOTHING.
  6. If a valid winner exists, it is written to active_strategy.json (by the
     caller / script).

A backtest is a filter against obvious overfitting, not a prediction.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

import numpy as np
import pandas as pd

from ..backtest.engine import BacktestResult, run_backtest
from ..backtest.metrics import Metrics, compute_metrics
from ..strategies.base import Strategy
from ..strategies.registry import BENCHMARK_NAME, build_candidates
from ..timeframes import Resolution
from ..logging_util import get_logger

log = get_logger("daytrader.selection")


@dataclass
class CandidateReport:
    name: str
    params: dict
    is_metrics: Metrics
    oos_metrics: Metrics
    oos_entries: int
    disqualified: bool = False
    dq_reason: str = ""
    is_benchmark: bool = False


@dataclass
class SelectionReport:
    symbol: str
    resolution: str
    ranking_metric: str
    split_date: Optional[str]
    train_bars: int
    oos_bars: int
    candidates: list[CandidateReport]
    benchmark: CandidateReport
    winner: Optional[str]        # promoted strategy name, or None
    winner_params: Optional[dict]
    no_edge: bool
    headline: str
    notes: list[str] = field(default_factory=list)
    walk_forward: bool = False


def _metric_value(m: Metrics, key: str) -> float:
    return float(getattr(m, key))


def _backtest_on(
    bars: pd.DataFrame,
    signals: pd.Series,
    cfg_bt,
    periods_per_year: float,
) -> tuple[BacktestResult, Metrics]:
    result = run_backtest(
        bars,
        signals,
        starting_cash=cfg_bt.starting_cash,
        commission_per_trade=cfg_bt.commission_per_trade,
        slippage_bps=cfg_bt.slippage_bps,
    )
    metrics = compute_metrics(
        result.equity_curve, result.round_trips, periods_per_year,
        result.exposure_fraction,
    )
    return result, metrics


def run_selection(config, bars: pd.DataFrame) -> SelectionReport:
    """Rank all candidates on `bars` and decide a winner (or NO EDGE FOUND)."""
    res: Resolution = config.resolution
    ppy = res.periods_per_year
    ranking_metric = config.selection.ranking_metric
    min_trades = config.selection.min_trades

    if config.selection.walk_forward:
        return _run_walk_forward(config, bars)

    n = len(bars)
    split_i = int(n * config.selection.train_frac)
    split_i = max(1, min(split_i, n - 1))
    is_bars = bars.iloc[:split_i]
    oos_bars = bars.iloc[split_i:]
    split_date = str(bars.index[split_i].date())
    log.info("split @ %s : IS=%d bars, OOS=%d bars", split_date, len(is_bars), len(oos_bars))

    candidates = build_candidates(config)
    reports: list[CandidateReport] = []
    benchmark_report: Optional[CandidateReport] = None

    for strat in candidates:
        # Signals on the FULL series (causal), then sliced — so OOS signals are
        # correctly warmed up from prior data without leaking the future.
        full_signals = strat.generate_signals(bars)
        is_sig = full_signals.loc[is_bars.index]
        oos_sig = full_signals.loc[oos_bars.index]

        _, is_m = _backtest_on(is_bars, is_sig, config.backtest, ppy)
        oos_res, oos_m = _backtest_on(oos_bars, oos_sig, config.backtest, ppy)
        # Count completed round-trip trades (matches the "trades=" column shown
        # in the report), so the disqualification message and the table agree.
        n_trades = oos_m.trade_count

        is_bench = strat.name == BENCHMARK_NAME
        rep = CandidateReport(
            name=strat.name,
            params=_strategy_params(strat),
            is_metrics=is_m,
            oos_metrics=oos_m,
            oos_entries=n_trades,
            is_benchmark=is_bench,
        )
        if not is_bench and n_trades < min_trades:
            rep.disqualified = True
            rep.dq_reason = f"only {n_trades} OOS trades (< min_trades={min_trades})"
        reports.append(rep)
        if is_bench:
            benchmark_report = rep

    assert benchmark_report is not None

    return _decide(config, reports, benchmark_report, ranking_metric,
                   config.symbol, res.raw, split_date, len(is_bars), len(oos_bars),
                   walk_forward=False)


def _decide(config, reports, benchmark_report, ranking_metric, symbol, resolution,
            split_date, train_bars, oos_bars, walk_forward: bool) -> SelectionReport:
    survivors = [r for r in reports if not r.is_benchmark and not r.disqualified]
    bench_val = _metric_value(benchmark_report.oos_metrics, ranking_metric)
    notes: list[str] = []

    survivors_sorted = sorted(
        survivors, key=lambda r: _metric_value(r.oos_metrics, ranking_metric), reverse=True
    )

    winner = None
    winner_params = None
    no_edge = True

    if not survivors_sorted:
        headline = "NO EDGE FOUND — no strategy cleared the minimum-trades filter out-of-sample."
        notes.append("Every active strategy was disqualified for too few OOS trades.")
    else:
        top = survivors_sorted[0]
        top_val = _metric_value(top.oos_metrics, ranking_metric)
        if top_val > bench_val:
            winner = top.name
            winner_params = top.params
            no_edge = False
            headline = (
                f"WINNER: {top.name} — OOS {ranking_metric}={top_val:.3f} "
                f"beats buy-and-hold ({bench_val:.3f})."
            )
        else:
            headline = (
                f"NO EDGE FOUND — best OOS {ranking_metric} was {top.name} "
                f"({top_val:.3f}), which does NOT beat buy-and-hold ({bench_val:.3f}). "
                f"Promoting nothing."
            )
            notes.append("Out-of-sample, none of the strategies beat simply holding the asset.")

    notes.append("Costs (commission + slippage) are modeled in every result above.")
    notes.append("A good backtest is not a prediction — OOS outperformance only "
                 "filters obvious overfitting.")

    return SelectionReport(
        symbol=symbol,
        resolution=resolution,
        ranking_metric=ranking_metric,
        split_date=split_date,
        train_bars=train_bars,
        oos_bars=oos_bars,
        candidates=reports,
        benchmark=benchmark_report,
        winner=winner,
        winner_params=winner_params,
        no_edge=no_edge,
        headline=headline,
        notes=notes,
        walk_forward=walk_forward,
    )


def _run_walk_forward(config, bars: pd.DataFrame, n_folds: int = 5) -> SelectionReport:
    """Rolling walk-forward: evaluate each candidate across several consecutive
    OOS test windows and aggregate. These strategies have fixed params (nothing
    is fit), so walk-forward here means a more robust multi-window OOS estimate:
    chain the per-fold OOS equity curves and score the combined curve.
    """
    res: Resolution = config.resolution
    ppy = res.periods_per_year
    ranking_metric = config.selection.ranking_metric
    min_trades = config.selection.min_trades

    n = len(bars)
    if n < n_folds * 3:
        log.warning("series too short for %d folds; falling back to single split", n_folds)
        cfg2 = config.model_copy(deep=True)
        cfg2.selection.walk_forward = False
        return run_selection(cfg2, bars)

    # Test windows = the last n_folds equal segments; first segment seeds warmup.
    bounds = np.linspace(0, n, n_folds + 2, dtype=int)
    test_windows = [(bounds[i], bounds[i + 1]) for i in range(1, n_folds + 1)]
    is_bars_count = bounds[1]
    oos_bars_count = n - bounds[1]

    candidates = build_candidates(config)
    reports: list[CandidateReport] = []
    benchmark_report: Optional[CandidateReport] = None

    for strat in candidates:
        full_signals = strat.generate_signals(bars)

        # In-sample = first segment; OOS aggregate = chained test windows.
        is_slice = bars.iloc[bounds[0]:bounds[1]]
        _, is_m = _backtest_on(is_slice, full_signals.loc[is_slice.index], config.backtest, ppy)

        chained_equity: list[pd.Series] = []
        all_round_trips: list[dict] = []
        exposures = []
        equity_level = config.backtest.starting_cash
        for (a, b) in test_windows:
            seg = bars.iloc[a:b]
            seg_sig = full_signals.loc[seg.index]
            seg_res, _ = _backtest_on(seg, seg_sig, config.backtest, ppy)
            # rescale this segment's curve to continue from the running level
            scale = equity_level / seg_res.starting_cash
            curve = seg_res.equity_curve * scale
            equity_level = float(curve.iloc[-1])
            chained_equity.append(curve)
            all_round_trips.extend(seg_res.round_trips)
            exposures.append(seg_res.exposure_fraction)

        oos_curve = pd.concat(chained_equity)
        oos_curve = oos_curve[~oos_curve.index.duplicated(keep="last")].sort_index()
        avg_exposure = float(np.mean(exposures)) if exposures else 0.0
        oos_m = compute_metrics(oos_curve, all_round_trips, ppy, avg_exposure)
        n_trades = oos_m.trade_count  # completed round-trips, matches the report

        is_bench = strat.name == BENCHMARK_NAME
        rep = CandidateReport(
            name=strat.name,
            params=_strategy_params(strat),
            is_metrics=is_m,
            oos_metrics=oos_m,
            oos_entries=n_trades,
            is_benchmark=is_bench,
        )
        if not is_bench and n_trades < min_trades:
            rep.disqualified = True
            rep.dq_reason = f"only {n_trades} OOS trades (< min_trades={min_trades})"
        reports.append(rep)
        if is_bench:
            benchmark_report = rep

    assert benchmark_report is not None
    report = _decide(config, reports, benchmark_report, ranking_metric,
                     config.symbol, res.raw, str(bars.index[is_bars_count].date()),
                     is_bars_count, oos_bars_count, walk_forward=True)
    report.notes.insert(0, f"Walk-forward: {n_folds} rolling OOS windows aggregated.")
    return report


def _strategy_params(strat: Strategy) -> dict:
    """Extract the tunable params from a strategy instance for reporting/JSON."""
    skip = {"name"}
    out = {}
    for k, v in vars(strat).items():
        if k in skip or k.startswith("_"):
            continue
        if isinstance(v, (int, float, str, bool)):
            out[k] = v
    return out
