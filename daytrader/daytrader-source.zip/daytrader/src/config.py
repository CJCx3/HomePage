"""Config loading + validation (pydantic v2).

Fails loudly on bad values. The two safety rules that live here:
  * `mode` must be one of backtest|select|paper|live.
  * `mode: live` refuses to load unless `i_understand_live_risk: true`.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Literal, Optional

import yaml
from pydantic import BaseModel, Field, ValidationError, field_validator, model_validator

from .timeframes import Resolution, parse_resolution

PROJECT_ROOT = Path(__file__).resolve().parent.parent


class DataConfig(BaseModel):
    source: Literal["yfinance", "alpaca"] = "alpaca"
    lookback_days: int = Field(45, gt=0)
    start: Optional[str] = "2018-01-01"
    end: Optional[str] = None  # null = up to today


class BacktestConfig(BaseModel):
    starting_cash: float = Field(10_000, gt=0)
    commission_per_trade: float = Field(0.0, ge=0)
    slippage_bps: float = Field(5.0, ge=0)


class SelectionConfig(BaseModel):
    train_frac: float = Field(0.7, gt=0.0, lt=1.0)
    min_trades: int = Field(10, ge=0)
    ranking_metric: Literal["sharpe", "sortino", "total_return", "cagr"] = "sharpe"
    walk_forward: bool = False
    auto_reselect: bool = False


class RiskConfig(BaseModel):
    max_daily_loss: float = Field(100.0, gt=0)  # kill switch cannot be disabled
    max_position_notional: float = Field(1000.0, gt=0)
    stop_loss_pct: Optional[float] = None  # e.g. 0.02 = 2% per-trade stop; null = off
    eod_flat: bool = True

    @field_validator("stop_loss_pct")
    @classmethod
    def _validate_stop(cls, v: Optional[float]) -> Optional[float]:
        if v is not None and not (0 < v < 1):
            raise ValueError("stop_loss_pct must be between 0 and 1 (e.g. 0.02), or null")
        return v


class MACrossoverParams(BaseModel):
    fast: int = Field(gt=0)
    slow: int = Field(gt=0)

    @model_validator(mode="after")
    def _fast_lt_slow(self):
        if self.fast >= self.slow:
            raise ValueError(f"ma_crossover: fast ({self.fast}) must be < slow ({self.slow})")
        return self


class RSIParams(BaseModel):
    period: int = Field(gt=1)
    oversold: float = Field(gt=0, lt=100)
    exit_level: float = Field(gt=0, lt=100)

    @model_validator(mode="after")
    def _oversold_lt_exit(self):
        if self.oversold >= self.exit_level:
            raise ValueError(
                f"rsi_reversion: oversold ({self.oversold}) must be < exit_level ({self.exit_level})"
            )
        return self


class BreakoutParams(BaseModel):
    lookback: int = Field(gt=1)


class TrendDipParams(BaseModel):
    """Hybrid: buy RSI dips only while the SMA trend filter says 'uptrend'."""
    trend_fast: int = Field(9, gt=0)
    trend_slow: int = Field(21, gt=0)
    rsi_period: int = Field(14, gt=1)
    oversold: float = Field(35, gt=0, lt=100)
    exit_level: float = Field(60, gt=0, lt=100)

    @model_validator(mode="after")
    def _validate(self):
        if self.trend_fast >= self.trend_slow:
            raise ValueError(
                f"trend_dip: trend_fast ({self.trend_fast}) must be < trend_slow ({self.trend_slow})"
            )
        if self.oversold >= self.exit_level:
            raise ValueError(
                f"trend_dip: oversold ({self.oversold}) must be < exit_level ({self.exit_level})"
            )
        return self


class StrategiesConfig(BaseModel):
    ma_crossover: MACrossoverParams
    rsi_reversion: RSIParams
    breakout: BreakoutParams
    # Optional with defaults so pre-existing config.yaml files still validate.
    trend_dip: TrendDipParams = Field(default_factory=TrendDipParams)


class Config(BaseModel):
    mode: Literal["backtest", "select", "paper", "live"] = "paper"
    i_understand_live_risk: bool = False
    symbol: str = "SPY"
    bar_resolution: str = "5Min"

    data: DataConfig = Field(default_factory=DataConfig)
    backtest: BacktestConfig = Field(default_factory=BacktestConfig)
    selection: SelectionConfig = Field(default_factory=SelectionConfig)
    risk: RiskConfig = Field(default_factory=RiskConfig)
    strategies: StrategiesConfig

    @field_validator("symbol")
    @classmethod
    def _upper_symbol(cls, v: str) -> str:
        return v.strip().upper()

    @model_validator(mode="after")
    def _validate_bar_resolution(self):
        # Raises ValueError with a clear message on a bad resolution string.
        parse_resolution(self.bar_resolution)
        return self

    @model_validator(mode="after")
    def _live_gate(self):
        # The single most important safety rule in the whole system.
        if self.mode == "live" and not self.i_understand_live_risk:
            raise ValueError(
                "REFUSING TO START in live mode.\n"
                "  mode: live trades REAL money, but i_understand_live_risk is not true.\n"
                "  To trade real money you must explicitly set BOTH in config.yaml:\n"
                "      mode: live\n"
                "      i_understand_live_risk: true\n"
                "  Until then, run in paper mode (the default)."
            )
        return self

    # -- convenience accessors -------------------------------------------------
    @property
    def resolution(self) -> Resolution:
        return parse_resolution(self.bar_resolution)

    @property
    def is_live(self) -> bool:
        return self.mode == "live"

    @property
    def broker_mode(self) -> str:
        """Endpoint selector for the broker: only 'live' uses real money."""
        return "live" if self.mode == "live" else "paper"


def load_config(path: str | os.PathLike | None = None) -> Config:
    """Load and validate config.yaml. Raises ConfigError (clear message) on failure."""
    cfg_path = Path(path) if path else PROJECT_ROOT / "config.yaml"
    if not cfg_path.exists():
        raise ConfigError(f"config file not found: {cfg_path}")
    with open(cfg_path, "r", encoding="utf-8") as fh:
        raw: dict[str, Any] = yaml.safe_load(fh) or {}
    try:
        return Config(**raw)
    except ValidationError as e:
        raise ConfigError(f"config.yaml failed validation:\n{e}") from e


class ConfigError(Exception):
    """Raised for any configuration problem, with an operator-friendly message."""
