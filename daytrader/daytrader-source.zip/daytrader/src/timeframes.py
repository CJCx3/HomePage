"""Bar-resolution helpers.

`bar_resolution` (e.g. "5Min", "1Min", "1Hour", "1Day") drives EVERY mode so
selection and live trading stay coherent. One place to translate a resolution
string into: the annualization factor for Sharpe, the yfinance interval, the
Alpaca TimeFrame, and the bar length in minutes for session logic.

Intraday reality: strategy params are in BARS, not clock time. SMA(20) is 20
days on "1Day" but 20 x 5min = 100 minutes on "5Min". Pick params for the
resolution you actually trade.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

# A regular US equity session is 9:30-16:00 ET = 6.5 hours = 390 minutes.
TRADING_MINUTES_PER_DAY = 390
TRADING_DAYS_PER_YEAR = 252

_UNIT_ALIASES = {
    "min": "Min",
    "minute": "Min",
    "mins": "Min",
    "m": "Min",
    "hour": "Hour",
    "hours": "Hour",
    "h": "Hour",
    "day": "Day",
    "days": "Day",
    "d": "Day",
}

_RESOLUTION_RE = re.compile(r"^\s*(\d+)\s*([A-Za-z]+)\s*$")


@dataclass(frozen=True)
class Resolution:
    """A parsed bar resolution with everything the system needs."""

    raw: str
    amount: int
    unit: str  # normalized: "Min" | "Hour" | "Day"

    @property
    def is_intraday(self) -> bool:
        return self.unit in ("Min", "Hour")

    @property
    def minutes(self) -> int:
        """Bar length in minutes (a trading day counts as 390 minutes)."""
        if self.unit == "Min":
            return self.amount
        if self.unit == "Hour":
            return self.amount * 60
        return TRADING_MINUTES_PER_DAY  # one "Day" bar

    @property
    def seconds(self) -> int:
        return self.minutes * 60

    @property
    def bars_per_day(self) -> float:
        if self.unit == "Day":
            return 1.0
        return TRADING_MINUTES_PER_DAY / self.minutes

    @property
    def periods_per_year(self) -> float:
        """Number of bars per year — the annualization base for Sharpe/CAGR.

        Daily = 252. Intraday multiplies by the number of bars in a session,
        so the Sharpe factor (sqrt of this) is much larger intraday. Getting
        this wrong makes intraday Sharpe look ~15x better than it is.
        """
        if self.unit == "Day":
            return float(TRADING_DAYS_PER_YEAR)
        return self.bars_per_day * TRADING_DAYS_PER_YEAR

    @property
    def yfinance_interval(self) -> str:
        if self.unit == "Min":
            return f"{self.amount}m"
        if self.unit == "Hour":
            return f"{self.amount}h"
        return "1d"

    @property
    def pandas_freq(self) -> str:
        if self.unit == "Min":
            return f"{self.amount}min"
        if self.unit == "Hour":
            return f"{self.amount}h"
        return "1D"

    def alpaca_timeframe(self):
        """Build an Alpaca TimeFrame. Imported lazily so pure-logic code
        (backtests, tests) never needs alpaca-py installed."""
        from alpaca.data.timeframe import TimeFrame, TimeFrameUnit

        unit_map = {
            "Min": TimeFrameUnit.Minute,
            "Hour": TimeFrameUnit.Hour,
            "Day": TimeFrameUnit.Day,
        }
        return TimeFrame(self.amount, unit_map[self.unit])


def parse_resolution(text: str) -> Resolution:
    """Parse '5Min' / '1Min' / '1Hour' / '1Day' into a Resolution.

    Raises ValueError on anything it does not understand, so a typo in
    config.yaml fails loudly instead of silently trading the wrong resolution.
    """
    if not isinstance(text, str):
        raise ValueError(f"bar_resolution must be a string, got {type(text)!r}")
    m = _RESOLUTION_RE.match(text)
    if not m:
        raise ValueError(
            f"Could not parse bar_resolution={text!r}. "
            "Use forms like '1Min', '5Min', '15Min', '1Hour', '1Day'."
        )
    amount = int(m.group(1))
    unit_raw = m.group(2).lower()
    if unit_raw not in _UNIT_ALIASES:
        raise ValueError(
            f"Unknown time unit in bar_resolution={text!r}. "
            "Supported units: Min, Hour, Day."
        )
    if amount <= 0:
        raise ValueError(f"bar_resolution amount must be positive, got {amount}")
    return Resolution(raw=text, amount=amount, unit=_UNIT_ALIASES[unit_raw])
