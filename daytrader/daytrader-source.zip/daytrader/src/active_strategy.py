"""Read/write active_strategy.json — the hot-reloaded active strategy.

The live runner re-reads this file at the top of every loop, so changing it
(via scripts/set_strategy.py or scripts/run_selection.py) takes effect on the
next cycle with no restart.
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .strategies.base import Strategy
from .strategies.registry import STRATEGIES, build_strategy

PROJECT_ROOT = Path(__file__).resolve().parent.parent
ACTIVE_PATH = PROJECT_ROOT / "active_strategy.json"


class ActiveStrategyError(Exception):
    pass


def load_active(path: str | Path | None = None) -> dict[str, Any]:
    p = Path(path) if path else ACTIVE_PATH
    if not p.exists():
        raise ActiveStrategyError(
            f"{p} not found. Create it with scripts/set_strategy.py or run selection."
        )
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        raise ActiveStrategyError(f"{p} is not valid JSON: {e}") from e
    name = data.get("name")
    if name not in STRATEGIES:
        raise ActiveStrategyError(
            f"active strategy {name!r} is unknown. Known: {', '.join(sorted(STRATEGIES))}"
        )
    return data


def build_active(path: str | Path | None = None) -> tuple[Strategy, dict[str, Any]]:
    """Load active_strategy.json and instantiate the strategy. Returns
    (strategy, raw_dict). Raises ActiveStrategyError on bad name/params."""
    data = load_active(path)
    try:
        strat = build_strategy(data["name"], data.get("params", {}))
    except (TypeError, ValueError, KeyError) as e:
        raise ActiveStrategyError(
            f"active strategy {data.get('name')!r} has invalid params "
            f"{data.get('params')}: {e}"
        ) from e
    return strat, data


def write_active(
    name: str,
    params: dict[str, Any],
    set_by: str,
    note: str = "",
    path: str | Path | None = None,
) -> Path:
    """Validate and atomically write active_strategy.json."""
    # Validate by constructing the strategy before writing.
    build_strategy(name, params)
    p = Path(path) if path else ACTIVE_PATH
    payload = {
        "name": name,
        "params": params,
        "set_by": set_by,
        "set_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "note": note or "Hot-reloaded by the live runner every cycle.",
    }
    tmp = p.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    tmp.replace(p)
    return p
