"""daytrader — a small, honest day-trading bot.

Modes: backtest | select | paper (default) | live.
Safety first: paper is the default, live refuses to start without an explicit
acknowledgement flag, and a max-daily-loss kill switch is mandatory and on.
"""

__version__ = "1.0.0"
