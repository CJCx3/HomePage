"""Historical + real-time bar loading (yfinance / alpaca)."""
