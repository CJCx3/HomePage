"""Historical bar loading for backtest / select.

Two sources:
  * yfinance  — no API key. Great for clean DAILY history; intraday is limited
    (yfinance only serves a few recent weeks of minute bars) and unreliable.
  * alpaca    — needs keys. Required for intraday history. On the FREE plan the
    only feed is IEX (~2.5% of volume), so intraday bars can be sparse/gappy.

Both paths return a normalized DataFrame:
    index : tz-aware DatetimeIndex (UTC), sorted ascending, unique
    cols  : open, high, low, close, volume  (lowercase, float)

Sparse/empty data is tolerated, not fatal: rows with no price are dropped and
the gap is logged. An empty result raises DataError with a clear message so
callers can react instead of crashing on an empty frame.
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional

import numpy as np
import pandas as pd

from ..logging_util import get_logger
from ..timeframes import Resolution, parse_resolution

log = get_logger("daytrader.data")

OHLCV = ["open", "high", "low", "close", "volume"]


class DataError(Exception):
    """Raised when data cannot be loaded or is unusable."""


def _normalize(df: pd.DataFrame, symbol: str) -> pd.DataFrame:
    """Flatten/relabel any provider frame into the OHLCV contract."""
    if df is None or len(df) == 0:
        return pd.DataFrame(columns=OHLCV)

    df = df.copy()

    # yfinance can hand back MultiIndex columns like (Open, SPY). Flatten by
    # keeping whichever level holds the OHLC field names.
    if isinstance(df.columns, pd.MultiIndex):
        level_scores = []
        for lvl in range(df.columns.nlevels):
            names = {str(x).lower() for x in df.columns.get_level_values(lvl)}
            level_scores.append(len({"open", "high", "low", "close"} & names))
        best = int(np.argmax(level_scores))
        df.columns = df.columns.get_level_values(best)

    # alpaca .df can carry a (symbol, timestamp) MultiIndex; keep timestamps.
    if isinstance(df.index, pd.MultiIndex):
        if symbol in df.index.get_level_values(0):
            df = df.xs(symbol, level=0)
        else:
            df = df.droplevel(0)

    df.columns = [str(c).lower().replace(" ", "_") for c in df.columns]
    rename = {"adj_close": "adj_close"}
    df = df.rename(columns=rename)

    for col in OHLCV:
        if col not in df.columns:
            if col == "volume":
                df["volume"] = 0.0
            else:
                raise DataError(f"loaded data for {symbol} is missing column '{col}'")

    df = df[OHLCV].apply(pd.to_numeric, errors="coerce")

    # Index -> tz-aware UTC DatetimeIndex, sorted & unique.
    df.index = pd.to_datetime(df.index, utc=True)
    df = df[~df.index.duplicated(keep="last")].sort_index()

    # Tolerate sparse/empty bars: drop rows with no usable price, log the gap.
    before = len(df)
    df = df.dropna(subset=["open", "high", "low", "close"])
    dropped = before - len(df)
    if dropped:
        log.info("dropped %d empty/NaN bar(s) for %s (sparse feed)", dropped, symbol)

    df["volume"] = df["volume"].fillna(0.0)
    return df


def _load_yfinance(symbol: str, res: Resolution, start, end) -> pd.DataFrame:
    import yfinance as yf

    kwargs = dict(
        interval=res.yfinance_interval,
        auto_adjust=True,
        progress=False,
        threads=False,
    )
    if res.is_intraday:
        # yfinance only serves recent intraday history; use a period window.
        # (5m ~ last 60 days, 1m ~ last 7 days.)
        kwargs["period"] = "60d" if res.unit == "Min" else "730d"
    else:
        kwargs["start"] = start
        kwargs["end"] = end

    log.info("yfinance: %s %s %s", symbol, res.raw, kwargs.get("period", f"{start}->{end}"))
    raw = yf.download(symbol, **kwargs)
    df = _normalize(raw, symbol)
    if res.is_intraday and start is not None:
        df = df[df.index >= pd.Timestamp(start, tz="UTC")]
    return df


def _load_alpaca(symbol: str, res: Resolution, start, end, key, secret) -> pd.DataFrame:
    from alpaca.data.historical import StockHistoricalDataClient
    from alpaca.data.requests import StockBarsRequest

    if not key or not secret:
        raise DataError(
            "source: alpaca requires ALPACA_API_KEY / ALPACA_SECRET_KEY in .env. "
            "For key-free history use source: yfinance (daily bars)."
        )
    client = StockHistoricalDataClient(key, secret)
    req = StockBarsRequest(
        symbol_or_symbols=symbol,
        timeframe=res.alpaca_timeframe(),
        start=start,
        end=end,
        feed="iex",  # free plan feed; SIP is a paid upgrade
    )
    log.info("alpaca(iex): %s %s %s->%s", symbol, res.raw, start, end)
    try:
        bars = client.get_stock_bars(req)
    except Exception as e:  # network / auth / rate-limit
        raise DataError(f"alpaca historical fetch failed: {e}") from e
    df = getattr(bars, "df", None)
    if df is None or len(df) == 0:
        raise DataError(
            f"alpaca returned no bars for {symbol} at {res.raw}. On the free IEX "
            "feed intraday history is thin; try bar_resolution: '1Day' or widen the window."
        )
    return _normalize(df, symbol)


def load_bars(
    symbol: str,
    resolution: str | Resolution,
    source: str = "yfinance",
    start: Optional[str | datetime] = None,
    end: Optional[str | datetime] = None,
    lookback_days: Optional[int] = None,
    key: Optional[str] = None,
    secret: Optional[str] = None,
    min_bars: int = 1,
) -> pd.DataFrame:
    """Load normalized OHLCV bars.

    For intraday resolutions `start` defaults to `lookback_days` ago. Raises
    DataError with an actionable message if fewer than `min_bars` are returned.
    """
    res = resolution if isinstance(resolution, Resolution) else parse_resolution(resolution)

    now = datetime.now(timezone.utc)
    if end is None:
        end = now
    if start is None:
        if res.is_intraday:
            days = lookback_days or 45
            start = now - timedelta(days=days)
        else:
            start = "2018-01-01"

    if source == "yfinance":
        df = _load_yfinance(symbol, res, start, end)
    elif source == "alpaca":
        df = _load_alpaca(symbol, res, start, end, key, secret)
    else:
        raise DataError(f"unknown data source: {source!r} (use 'yfinance' or 'alpaca')")

    if len(df) < min_bars:
        raise DataError(
            f"only {len(df)} bar(s) loaded for {symbol} at {res.raw} from {source}; "
            f"need >= {min_bars}. Widen the date range, lower the resolution, or "
            f"switch source."
        )
    log.info("loaded %d bars for %s @ %s (%s)", len(df), symbol, res.raw, source)
    return df
