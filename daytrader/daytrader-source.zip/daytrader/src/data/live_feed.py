"""Real-time bar feed (Alpaca, free IEX feed).

Design choice: POLL the historical endpoint at the bar cadence rather than hold
a websocket open. On the free tier this is simpler and robust — the historical
endpoint only returns CLOSED bars, so there is no in-progress bar to leak into a
signal (no lookahead in live). We additionally drop any bar whose period has not
finished as of `now`, belt-and-suspenders.

Free IEX data is thin (~2.5% of volume): intraday bars can be sparse or have
gaps. This feed tolerates that — it fetches a generous window, keeps whatever
closed bars exist, and never crashes on an empty pull (it logs and returns what
it has). Rate limits: the runner calls this once per bar, not every second.

The StockDataStream websocket is the lower-latency alternative; polling is the
deliberate, dependency-light default here.
"""

from __future__ import annotations

import math
from datetime import datetime, timedelta, timezone
from typing import Optional
from zoneinfo import ZoneInfo

import pandas as pd

from ..logging_util import get_logger
from ..timeframes import Resolution
from .loader import _normalize

log = get_logger("daytrader.feed")
NY = ZoneInfo("America/New_York")


class LiveFeed:
    def __init__(self, symbol: str, resolution: Resolution, key: str, secret: str):
        from alpaca.data.historical import StockHistoricalDataClient

        self.symbol = symbol
        self.res = resolution
        self._client = StockHistoricalDataClient(key, secret)

    # -- fetching --------------------------------------------------------------
    def _lookback_days(self, bars_needed: int) -> int:
        if self.res.unit == "Day":
            return int(bars_needed * 2 + 7)  # weekends/holidays margin
        per_day = max(self.res.bars_per_day, 1.0)
        return int(math.ceil(bars_needed / per_day) + 4)  # +4 days slack for gaps

    def _fetch(self, start: datetime, end: datetime) -> pd.DataFrame:
        from alpaca.data.requests import StockBarsRequest

        req = StockBarsRequest(
            symbol_or_symbols=self.symbol,
            timeframe=self.res.alpaca_timeframe(),
            start=start,
            end=end,
            feed="iex",
        )
        try:
            bars = self._client.get_stock_bars(req)
        except Exception as e:
            log.warning("live fetch failed (%s); returning empty window", e)
            return pd.DataFrame(columns=["open", "high", "low", "close", "volume"])
        df = getattr(bars, "df", None)
        if df is None or len(df) == 0:
            log.info("live fetch returned no bars for %s (sparse feed / market closed)", self.symbol)
            return pd.DataFrame(columns=["open", "high", "low", "close", "volume"])
        return _normalize(df, self.symbol)

    def get_closed_bars(self, bars_needed: int, now: Optional[datetime] = None) -> pd.DataFrame:
        """Return up to the most recent `bars_needed` CLOSED bars.

        Never returns an in-progress bar (no lookahead):
          * Intraday: a bar is closed once `timestamp + bar_length <= now`.
          * Daily: Alpaca stamps a daily bar at ~midnight UTC of its date, so
            the duration trick doesn't apply. A daily bar for date D is only
            complete after D's session close, so we use only bars dated strictly
            BEFORE today (ET) — i.e. the last COMPLETED session. Deciding on
            yesterday's bar and executing today matches the backtest's
            "signal at t, fill at t+1" convention.
        """
        now = now or datetime.now(timezone.utc)
        start = now - timedelta(days=self._lookback_days(bars_needed + 5))
        df = self._fetch(start, now)
        if len(df):
            if self.res.unit == "Day":
                today_et = pd.Timestamp(now).tz_convert(NY).date()
                dates_et = df.index.tz_convert(NY).date
                df = df[[d < today_et for d in dates_et]]
            else:
                bar_end = df.index + pd.Timedelta(seconds=self.res.seconds)
                df = df[bar_end <= pd.Timestamp(now)]
        if len(df) > bars_needed:
            df = df.iloc[-bars_needed:]
        return df

    def backfill(self, warmup_bars: int, now: Optional[datetime] = None) -> pd.DataFrame:
        """Seed the rolling window on startup so the runner can act on the first
        live bar instead of sitting idle for `warmup_bars` bars."""
        df = self.get_closed_bars(warmup_bars, now=now)
        log.info("backfilled %d closed bars for %s @ %s (warmup=%d)",
                 len(df), self.symbol, self.res.raw, warmup_bars)
        if 0 < len(df) < warmup_bars:
            log.warning("backfill got %d < warmup %d bars — thin IEX feed; the "
                        "runner will wait for more bars before signaling",
                        len(df), warmup_bars)
        return df

    # -- timing ----------------------------------------------------------------
    def seconds_to_next_bar_close(self, now: Optional[datetime] = None) -> float:
        """Seconds until the current bar period closes (for pacing the loop)."""
        now = now or datetime.now(timezone.utc)
        step = self.res.seconds
        epoch = now.timestamp()
        return step - (epoch % step)
