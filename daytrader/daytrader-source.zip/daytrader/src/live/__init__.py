"""The live trading loop (paper & live share the same code path)."""
