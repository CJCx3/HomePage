"""The trading loop — identical code path for paper and live.

On each closed bar (spec section 6.6):
  1. Check risk FIRST. If the kill switch is tripped, do nothing but ensure flat.
  2. Hot-reload the active strategy from active_strategy.json.
  3. Compute the target from the LATEST CLOSED bar window (no in-progress bar,
     so no lookahead).
  4. Read the current broker position; if target != current, reconcile with
     notional (dollar) orders.
  5. Apply per-trade stop-loss and EOD flat rules if enabled.
  6. Log the decision / order / running P&L to reports/ and update state/.

Resilient by design: broker/network errors in a cycle are logged and the loop
continues — it never crashes silently into an unmanaged position.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from zoneinfo import ZoneInfo

from ..active_strategy import build_active
from ..execution.broker import Broker, BrokerError
from ..data.live_feed import LiveFeed
from ..logging_util import get_logger
from ..risk.controls import RiskManager

NY = ZoneInfo("America/New_York")
WARMUP_BUFFER = 5  # extra bars beyond the strategy's stated warmup


@dataclass
class RunnerStats:
    iterations: int = 0
    orders_submitted: int = 0
    buys: int = 0
    sells: int = 0
    last_target: int | None = None
    strategy_swaps: int = 0
    killswitch_tripped: bool = False
    notes: list[str] = field(default_factory=list)


class LiveRunner:
    def __init__(self, config, key: str | None = None, secret: str | None = None,
                 state_dir=None, broker=None, feed=None):
        self.config = config
        self.symbol = config.symbol
        self.res = config.resolution
        self.risk = RiskManager(config, state_dir)
        day = datetime.now(NY).strftime("%Y%m%d")
        self.log = get_logger("daytrader.runner", logfile=f"live_{day}.log")

        # broker/feed are injectable for testing; otherwise built from keys.
        self.broker = broker or Broker(config.broker_mode, key, secret)
        self.feed = feed or LiveFeed(self.symbol, self.res, key, secret)

        self._active_key: tuple | None = None
        self.stats = RunnerStats()

    # -- strategy hot-reload ---------------------------------------------------
    def _load_strategy(self):
        strat, data = build_active()
        key = (data["name"], tuple(sorted((data.get("params") or {}).items())))
        changed = key != self._active_key
        if changed:
            if self._active_key is not None:
                self.stats.strategy_swaps += 1
            self._active_key = key
            self.log.info("ACTIVE STRATEGY: %s %s (set_by=%s) %s",
                          data["name"], data.get("params"), data.get("set_by", "?"),
                          "[SWAP]" if self.stats.strategy_swaps and self._active_key else "")
        return strat, data, changed

    # -- main entry ------------------------------------------------------------
    def run(self, max_iterations: int | None = None, poll_seconds: float | None = None,
            until_close: bool = False, max_runtime_hours: float = 9.0) -> RunnerStats:
        """Run the loop.

        until_close=True is "session mode": if the market is closed, wait for the
        open; trade every bar while it's open; and stop once the session has
        closed (a full trading day). `max_runtime_hours` is a hard backstop so a
        scheduled run can never linger indefinitely.
        """
        mode = self.config.broker_mode.upper()
        self.log.info("=" * 60)
        self.log.info("daytrader runner starting — mode=%s symbol=%s res=%s%s",
                      mode, self.symbol, self.res.raw,
                      " [session: run until close]" if until_close else "")
        if self.config.is_live:
            self.log.warning("LIVE MODE: this is REAL MONEY.")

        # -- startup: clock, baseline, warmup backfill --
        try:
            clock = self.broker.get_clock()
            acct = self.broker.get_account()
        except BrokerError as e:
            self.log.error("startup failed talking to broker: %s", e)
            raise
        self._log_clock(clock)
        self.risk.start_session(acct.equity)
        self.log.info("account equity=%.2f cash=%.2f | session baseline=%.2f | killswitch=%s",
                      acct.equity, acct.cash, self.risk.state.starting_equity,
                      "TRIPPED" if self.risk.is_tripped() else "armed")
        if self.risk.is_tripped():
            self.log.error("Kill switch is TRIPPED from a prior session. Reset with "
                           "`python scripts/reset_killswitch.py` before trading.")

        self._close_orphan_positions(clock)

        strat, _, _ = self._load_strategy()
        warmup = strat.warmup + WARMUP_BUFFER
        self.feed.backfill(warmup)  # seed so we can act on the first bar

        start_wall = time.time()
        traded_while_open = False
        i = 0
        try:
            while max_iterations is None or i < max_iterations:
                if max_runtime_hours and (time.time() - start_wall) > max_runtime_hours * 3600:
                    self.log.info("max runtime (%.1fh) reached — stopping.", max_runtime_hours)
                    break

                # Session mode: wait for the open, and stop once it has closed.
                if until_close:
                    try:
                        clk = self.broker.get_clock()
                    except BrokerError as e:
                        self.log.error("clock check failed (continuing): %s", e)
                        time.sleep(30)
                        continue
                    if not clk.is_open:
                        if traded_while_open:
                            self.log.info("market has closed — full-day session complete, stopping.")
                            break
                        secs = max(0.0, (clk.next_open - datetime.now(timezone.utc)).total_seconds())
                        wait = max(30.0, min(secs, 300.0))
                        self.log.info("market closed; waiting for open at %s (~%.0f min away) ...",
                                      clk.next_open.astimezone(NY).strftime("%Y-%m-%d %H:%M %Z"),
                                      secs / 60)
                        time.sleep(wait)
                        continue
                    traded_while_open = True

                try:
                    self._cycle()
                except BrokerError as e:
                    self.log.error("broker error this cycle (continuing): %s", e)
                except Exception as e:  # keep the loop alive; never die into a position
                    self.log.exception("unexpected error this cycle (continuing): %s", e)
                self.stats.iterations += 1
                i += 1
                if max_iterations is not None and i >= max_iterations:
                    break

                if until_close:
                    sleep_s = max(5.0, min(self.feed.seconds_to_next_bar_close(), 300.0))
                else:
                    sleep_s = poll_seconds if poll_seconds is not None else \
                        max(2.0, self.feed.seconds_to_next_bar_close())
                self.log.info("... sleeping %.0fs until next bar close", sleep_s)
                time.sleep(sleep_s)
        except KeyboardInterrupt:
            self.log.info("interrupted by operator (Ctrl-C). Positions are left as-is "
                          "(paper) — use EOD flat or close manually if desired.")

        # Session end: make sure nothing is held overnight if EOD-flat is on.
        if until_close and self.config.risk.eod_flat and not self.risk.is_tripped():
            try:
                if abs(self.broker.get_position(self.symbol)) > 0:
                    self.log.info("session end: flattening residual position (eod_flat).")
                    self.broker.close_all()
            except BrokerError as e:
                self.log.error("session-end flatten failed: %s", e)

        self.log.info("runner stopped after %d cycle(s); orders submitted=%d (buys=%d, sells=%d)",
                      self.stats.iterations, self.stats.orders_submitted,
                      self.stats.buys, self.stats.sells)
        return self.stats

    # -- one loop iteration ----------------------------------------------------
    def _cycle(self) -> None:
        # 1) RISK FIRST
        clock = self.broker.get_clock()
        acct = self.broker.get_account()
        equity = acct.equity

        if self.risk.is_tripped():
            self.stats.killswitch_tripped = True
            self.log.error("KILL SWITCH TRIPPED — refusing to trade. "
                           "Reset with scripts/reset_killswitch.py")
            pos = self.broker.get_position(self.symbol)
            if abs(pos) > 0:
                self.log.error("flattening residual position (%.4f) while tripped", pos)
                self.broker.close_all()
            return

        if self.risk.enforce(equity, self.broker):
            self.stats.killswitch_tripped = True
            self.log.error("Daily-loss limit hit -> halted trading and flattened. Stays "
                           "tripped until manual reset.")
            return

        # 2) HOT-RELOAD STRATEGY
        strat, data, changed = self._load_strategy()
        warmup = strat.warmup + WARMUP_BUFFER

        # 3) LATEST CLOSED BARS
        window = self.feed.get_closed_bars(warmup)
        if len(window) < strat.warmup + 1:
            self.log.info("have %d closed bars (< warmup %d) — waiting for more data "
                          "(thin IEX feed or market closed)", len(window), strat.warmup)
            return

        # 4) SIGNAL FROM THE LATEST CLOSED BAR
        signals = strat.generate_signals(window)
        target = int(signals.iloc[-1])
        last_ts = window.index[-1]
        last_close = float(window["close"].iloc[-1])

        # 5) STOP-LOSS + EOD FLAT overrides
        current_qty = self.broker.get_position(self.symbol)
        if current_qty > 0 and self.config.risk.stop_loss_pct is not None:
            details = self.broker.get_position_details(self.symbol)
            if details and self.risk.stop_loss_hit(details["avg_entry"], last_close):
                self.log.warning("STOP-LOSS: entry=%.2f last=%.2f (%.1f%% stop) -> exit",
                                 details["avg_entry"], last_close,
                                 self.config.risk.stop_loss_pct * 100)
                target = 0

        eod = self.risk.should_eod_flat(clock.next_close)
        if eod and target == 1:
            self.log.info("EOD flat window (within a few min of close) -> overriding target to 0")
            target = 0

        session_pnl = equity - (self.risk.state.starting_equity or equity)
        self.log.info("bar=%s close=%.2f | target=%d pos=%.4f | equity=%.2f sessionP&L=%+.2f",
                      last_ts, last_close, target, current_qty, equity, session_pnl)
        self.stats.last_target = target

        # 6) RECONCILE with notional orders
        if target == 1 and current_qty == 0:
            if not clock.is_open:
                self.log.info("market CLOSED -> not submitting BUY (notional/fractional "
                              "orders are regular-hours only). Would buy $%.2f of %s.",
                              self.risk.clamp_notional(self.config.risk.max_position_notional),
                              self.symbol)
                return
            notional = self.risk.clamp_notional(self.config.risk.max_position_notional)
            self.broker.submit_notional(self.symbol, "buy", notional)
            self.stats.orders_submitted += 1
            self.stats.buys += 1
        elif target == 0 and current_qty > 0:
            self.log.info("closing position in %s (target flat)", self.symbol)
            self.broker.close_position(self.symbol)
            self.stats.orders_submitted += 1
            self.stats.sells += 1
        else:
            self.log.info("no action — already at target (%s)",
                          "long" if target == 1 else "flat")

    def _close_orphan_positions(self, clock) -> None:
        """Close any position that isn't the configured symbol — e.g. after the
        operator switches `symbol`. Prevents leaving an unmanaged position behind.
        Closing needs regular hours (market order); if closed, it's deferred to
        the next session and logged."""
        try:
            positions = self.broker.get_all_positions()
        except BrokerError as e:
            self.log.error("orphan check failed (continuing): %s", e)
            return
        for p in positions:
            sym = getattr(p, "symbol", None)
            qty = float(getattr(p, "qty", 0) or 0)
            if sym and sym != self.symbol and abs(qty) > 0:
                if clock.is_open:
                    self.log.warning("closing ORPHAN position %s %s (configured symbol is %s)",
                                     qty, sym, self.symbol)
                    try:
                        self.broker.close_position(sym)
                    except BrokerError as e:
                        self.log.error("failed to close orphan %s: %s", sym, e)
                else:
                    self.log.warning("orphan position %s %s held — market closed; will close "
                                     "when it next opens (configured symbol is %s)",
                                     qty, sym, self.symbol)

    # -- helpers ---------------------------------------------------------------
    def _log_clock(self, clock) -> None:
        no = clock.next_open.astimezone(NY).strftime("%Y-%m-%d %H:%M %Z")
        nc = clock.next_close.astimezone(NY).strftime("%Y-%m-%d %H:%M %Z")
        if clock.is_open:
            self.log.info("market is OPEN (next close %s)", nc)
        else:
            self.log.info("market is CLOSED (next open %s). No trades until it opens.", no)
