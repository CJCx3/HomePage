"""Rendering: equity-curve PNGs and the selection report (console + file)."""

from __future__ import annotations

from pathlib import Path
from typing import Optional

import pandas as pd

from ..backtest.metrics import Metrics
from ..logging_util import PROJECT_ROOT

REPORTS_DIR = PROJECT_ROOT / "reports"


def save_equity_curve_png(
    strategy_curve: pd.Series,
    benchmark_curve: pd.Series,
    title: str,
    out_path: str | Path,
    strategy_label: str = "strategy",
) -> Path:
    """Plot strategy equity vs buy-and-hold and save a PNG."""
    import matplotlib
    matplotlib.use("Agg")  # headless
    import matplotlib.pyplot as plt

    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    fig, ax = plt.subplots(figsize=(11, 6))
    ax.plot(strategy_curve.index, strategy_curve.values, label=strategy_label, linewidth=1.6)
    if benchmark_curve is not None and len(benchmark_curve):
        ax.plot(benchmark_curve.index, benchmark_curve.values,
                label="buy_and_hold", linewidth=1.3, alpha=0.8, linestyle="--")
    ax.set_title(title)
    ax.set_xlabel("time")
    ax.set_ylabel("equity ($)")
    ax.legend(loc="best")
    ax.grid(True, alpha=0.3)
    fig.autofmt_xdate()
    fig.tight_layout()
    fig.savefig(out_path, dpi=110)
    plt.close(fig)
    return out_path


def _fmt_metrics_row(name: str, m: Metrics, extra: str = "") -> str:
    return (
        f"  {name:<16} ret={m.total_return:+8.2%}  sharpe={m.sharpe:6.2f}  "
        f"maxDD={m.max_drawdown:7.2%}  trades={m.trade_count:>3}  "
        f"win={m.win_rate:5.0%}  exp={m.exposure:4.0%}{extra}"
    )


def format_selection_report(report) -> str:
    """Human-readable selection report as a string (also written to a file)."""
    lines: list[str] = []
    L = lines.append

    L("=" * 78)
    L(f"  SELECTION REPORT — {report.symbol} @ {report.resolution}"
      + ("  [walk-forward]" if report.walk_forward else ""))
    L("=" * 78)
    L(f"  ranking metric : OOS {report.ranking_metric}")
    L(f"  split date     : {report.split_date}  (IS={report.train_bars} bars, "
      f"OOS={report.oos_bars} bars)")
    L("")
    L("  IN-SAMPLE (training window)")
    for c in report.candidates:
        L(_fmt_metrics_row(c.name, c.is_metrics))
    L("")
    L("  OUT-OF-SAMPLE (held-out window — this is what ranking uses)")
    for c in report.candidates:
        tag = ""
        if c.is_benchmark:
            tag = "   <- benchmark"
        elif c.disqualified:
            tag = f"   <- DISQUALIFIED: {c.dq_reason}"
        L(_fmt_metrics_row(c.name, c.oos_metrics, tag))
    L("")
    L("-" * 78)
    L(f"  RESULT: {report.headline}")
    if report.winner:
        L(f"  Promoted to active_strategy.json: {report.winner} {report.winner_params}")
    else:
        L("  active_strategy.json is UNCHANGED (nothing promoted).")
    L("-" * 78)
    for note in report.notes:
        L(f"  note: {note}")
    L("=" * 78)
    return "\n".join(lines)


def write_selection_report(report, out_path: Optional[str | Path] = None) -> Path:
    text = format_selection_report(report)
    if out_path is None:
        REPORTS_DIR.mkdir(parents=True, exist_ok=True)
        out_path = REPORTS_DIR / "selection_report.txt"
    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(text, encoding="utf-8")
    return out_path
