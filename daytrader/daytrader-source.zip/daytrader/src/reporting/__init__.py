"""Reports: equity-curve PNGs, selection reports, live status."""
