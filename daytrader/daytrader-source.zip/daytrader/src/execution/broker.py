"""Alpaca broker adapter (alpaca-py).

Paper vs live is chosen ONLY by `mode`; nothing else in the trading code path
differs. `TradingClient(key, secret, paper=True)` hits the paper endpoint;
`paper=False` hits live (real money).

Sizing uses NOTIONAL (dollar) market orders. Whole-share sizing with a small
dollar cap and a ~$600 share rounds to 0 shares and the bot silently never
trades; notional orders are inherently fractional and work at any price. Note:
notional/fractional market orders are REGULAR-HOURS ONLY (Alpaca constraint).
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Optional

from ..logging_util import get_logger

log = get_logger("daytrader.broker")


@dataclass
class AccountSnapshot:
    equity: float
    cash: float
    buying_power: float
    last_equity: float


@dataclass
class ClockSnapshot:
    timestamp: datetime      # tz-aware (UTC)
    is_open: bool
    next_open: datetime      # tz-aware (UTC)
    next_close: datetime     # tz-aware (UTC)


class BrokerError(Exception):
    """Raised for broker/network failures the runner should log and survive."""


class Broker:
    """Thin wrapper over Alpaca's TradingClient with the operations the runner
    needs. Every call that hits the network raises BrokerError on failure so the
    trading loop can log and continue instead of crashing into an unmanaged
    position."""

    def __init__(self, mode: str, key: str, secret: str):
        if not key or not secret:
            raise BrokerError(
                "Missing Alpaca keys. Copy .env.example -> .env and paste your "
                "paper keys (ALPACA_API_KEY / ALPACA_SECRET_KEY)."
            )
        from alpaca.trading.client import TradingClient

        self.mode = mode
        self.paper = mode != "live"  # only 'live' uses real money
        try:
            self.client = TradingClient(key, secret, paper=self.paper)
        except Exception as e:
            raise BrokerError(f"could not create TradingClient: {e}") from e
        log.info("broker connected: endpoint=%s", "PAPER" if self.paper else "LIVE (real money)")

    # -- account / clock -------------------------------------------------------
    def get_account(self) -> AccountSnapshot:
        try:
            a = self.client.get_account()
        except Exception as e:
            raise BrokerError(f"get_account failed: {e}") from e
        return AccountSnapshot(
            equity=float(a.equity),
            cash=float(a.cash),
            buying_power=float(a.buying_power),
            last_equity=float(a.last_equity),
        )

    def get_equity(self) -> float:
        return self.get_account().equity

    def get_clock(self) -> ClockSnapshot:
        try:
            c = self.client.get_clock()
        except Exception as e:
            raise BrokerError(f"get_clock failed: {e}") from e
        return ClockSnapshot(
            timestamp=c.timestamp,
            is_open=bool(c.is_open),
            next_open=c.next_open,
            next_close=c.next_close,
        )

    # -- positions -------------------------------------------------------------
    def get_position(self, symbol: str) -> float:
        """Signed share quantity for `symbol`; 0.0 if flat.

        Always read from the broker — never assume flat after a restart.
        """
        try:
            pos = self.client.get_open_position(symbol)
            return float(pos.qty)
        except Exception as e:
            # alpaca raises when there is no open position; treat as flat.
            if _is_no_position(e):
                return 0.0
            raise BrokerError(f"get_position({symbol}) failed: {e}") from e

    def get_position_value(self, symbol: str) -> float:
        try:
            pos = self.client.get_open_position(symbol)
            return float(pos.market_value)
        except Exception as e:
            if _is_no_position(e):
                return 0.0
            raise BrokerError(f"get_position_value({symbol}) failed: {e}") from e

    def get_all_positions(self) -> list:
        """Every open position (used to detect/close orphans after a symbol switch)."""
        try:
            return self.client.get_all_positions()
        except Exception as e:
            raise BrokerError(f"get_all_positions failed: {e}") from e

    def get_position_details(self, symbol: str) -> Optional[dict]:
        """Full position snapshot, or None if flat. Used for stop-loss checks."""
        try:
            pos = self.client.get_open_position(symbol)
        except Exception as e:
            if _is_no_position(e):
                return None
            raise BrokerError(f"get_position_details({symbol}) failed: {e}") from e
        return {
            "qty": float(pos.qty),
            "avg_entry": float(pos.avg_entry_price),
            "market_value": float(pos.market_value),
            "unrealized_pl": float(pos.unrealized_pl),
        }

    # -- orders ----------------------------------------------------------------
    def submit_notional(self, symbol: str, side: str, notional: float):
        """Submit a market order for a DOLLAR amount (fractional-friendly)."""
        from alpaca.trading.enums import OrderSide, TimeInForce
        from alpaca.trading.requests import MarketOrderRequest

        order_side = OrderSide.BUY if side.lower() == "buy" else OrderSide.SELL
        req = MarketOrderRequest(
            symbol=symbol,
            notional=round(float(notional), 2),
            side=order_side,
            time_in_force=TimeInForce.DAY,
        )
        try:
            order = self.client.submit_order(order_data=req)
        except Exception as e:
            raise BrokerError(f"submit_notional {side} ${notional:.2f} {symbol} failed: {e}") from e
        log.info("ORDER submitted: %s $%.2f %s -> id=%s status=%s",
                 side.upper(), notional, symbol, getattr(order, "id", "?"),
                 getattr(order, "status", "?"))
        return order

    def submit_qty(self, symbol: str, side: str, qty: float):
        """Submit a market order for a WHOLE share quantity.

        The runner sizes with notional (fractional) orders during regular hours;
        this whole-share path is the fallback for when fractional isn't allowed
        (e.g. a market DAY order submitted while closed is queued to next open).
        """
        from alpaca.trading.enums import OrderSide, TimeInForce
        from alpaca.trading.requests import MarketOrderRequest

        order_side = OrderSide.BUY if side.lower() == "buy" else OrderSide.SELL
        req = MarketOrderRequest(
            symbol=symbol, qty=qty, side=order_side, time_in_force=TimeInForce.DAY,
        )
        try:
            order = self.client.submit_order(order_data=req)
        except Exception as e:
            raise BrokerError(f"submit_qty {side} {qty} {symbol} failed: {e}") from e
        log.info("ORDER submitted: %s %s %s -> id=%s status=%s",
                 side.upper(), qty, symbol, getattr(order, "id", "?"),
                 getattr(order, "status", "?"))
        return order

    def get_open_orders(self):
        try:
            return self.client.get_orders()
        except Exception as e:
            raise BrokerError(f"get_open_orders failed: {e}") from e

    def cancel_all_orders(self):
        try:
            res = self.client.cancel_orders()
            log.info("cancelled all open orders")
            return res
        except Exception as e:
            raise BrokerError(f"cancel_all_orders failed: {e}") from e

    def close_position(self, symbol: str):
        """Close the entire position in `symbol` (fractional-safe)."""
        try:
            order = self.client.close_position(symbol)
            log.info("CLOSE submitted for %s -> id=%s", symbol, getattr(order, "id", "?"))
            return order
        except Exception as e:
            if _is_no_position(e):
                log.info("close_position(%s): already flat", symbol)
                return None
            raise BrokerError(f"close_position({symbol}) failed: {e}") from e

    def close_all(self):
        """Flatten everything and cancel open orders. Used by the kill switch
        and end-of-day flat-out."""
        try:
            res = self.client.close_all_positions(cancel_orders=True)
            log.info("CLOSE_ALL submitted (cancel_orders=True)")
            return res
        except Exception as e:
            raise BrokerError(f"close_all failed: {e}") from e


def _is_no_position(exc: Exception) -> bool:
    """Alpaca signals 'no open position' with a 404 / 'position does not exist'."""
    text = str(exc).lower()
    if "position does not exist" in text or "404" in text or "not found" in text:
        return True
    code = getattr(exc, "status_code", None)
    return code == 404
