"""Broker execution adapters (Alpaca)."""
