"""Moving-average crossover: long while fast SMA is above slow SMA, else flat.

Params are in BARS. On "1Day" fast=20 means 20 days; on "5Min" it means
20 x 5min = 100 minutes. Choose params for the resolution you trade.
"""

from __future__ import annotations

import pandas as pd

from .base import Strategy, _clean_signal


class MACrossover(Strategy):
    name = "ma_crossover"

    def __init__(self, fast: int = 20, slow: int = 50):
        if fast >= slow:
            raise ValueError(f"ma_crossover needs fast < slow (got {fast}, {slow})")
        self.fast = int(fast)
        self.slow = int(slow)

    @property
    def warmup(self) -> int:
        return self.slow

    def generate_signals(self, bars: pd.DataFrame) -> pd.Series:
        close = self._close(bars)
        sma_fast = close.rolling(self.fast, min_periods=self.fast).mean()
        sma_slow = close.rolling(self.slow, min_periods=self.slow).mean()
        # Long when the fast average is above the slow average. Both rolling
        # means look only backwards, so this is causal by construction.
        raw = (sma_fast > sma_slow).astype(float)
        # Before slow SMA is warmed up both are NaN -> comparison is False -> 0.
        return _clean_signal(raw, bars.index)
