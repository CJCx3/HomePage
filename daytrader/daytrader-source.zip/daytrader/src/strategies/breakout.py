"""Donchian-channel breakout: long on a new N-bar high, flat on a new N-bar low.

The channel is built from the PRIOR `lookback` bars (shift(1)), so the current
bar's own high/low never leaks into its own breakout test — that shift is what
keeps the signal causal and non-trivial.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from .base import Strategy, _clean_signal


class Breakout(Strategy):
    name = "breakout"

    def __init__(self, lookback: int = 20):
        if lookback < 2:
            raise ValueError("breakout lookback must be >= 2")
        self.lookback = int(lookback)

    @property
    def warmup(self) -> int:
        # lookback bars to build the channel + 1 for the shift.
        return self.lookback + 1

    def generate_signals(self, bars: pd.DataFrame) -> pd.Series:
        high = bars["high"].astype(float)
        low = bars["low"].astype(float)
        close = bars["close"].astype(float)

        # Channel from the PRIOR window only (shift(1) excludes the current bar).
        upper = high.rolling(self.lookback, min_periods=self.lookback).max().shift(1)
        lower = low.rolling(self.lookback, min_periods=self.lookback).min().shift(1)

        state = pd.Series(np.nan, index=close.index, dtype="float64")
        state[close > upper] = 1.0  # breakout up -> go long
        state[close < lower] = 0.0  # breakdown -> go flat
        state = state.ffill()
        return _clean_signal(state, bars.index)
