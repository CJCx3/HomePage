"""Strategy implementations and the name -> class registry."""
