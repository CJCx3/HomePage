"""trend_dip — a hybrid of trend-following and mean-reversion.

The idea: BUY THE DIP, but only while the bigger trend is up; then hold until
it has clearly recovered OR the trend actually rolls over.

This merges the redeeming quality of each style while cancelling the other's
worst failure mode:

  * Trend filter (from ma_crossover): fast SMA > slow SMA defines an "uptrend".
    We are only ALLOWED to be long while that's true. This is the falling-knife
    protection that plain mean-reversion lacks.
  * RSI dip timing (from rsi_reversion): inside an uptrend, enter when RSI dips
    below `oversold` — buying temporary weakness at better prices instead of
    chasing strength.
  * Exit: RSI climbs back above `exit_level` (take the recovery) OR the trend
    rolls over (fast SMA falls back below slow SMA). That trend-rollover exit is
    the "sell only if it starts to dip again" behavior — it holds the winner
    through the bounce and steps aside when the tide genuinely turns.

Every calculation is causal (rolling / ewm / shift look only backward), so the
no-lookahead contract holds.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from .base import Strategy, _clean_signal
from .rsi_reversion import rsi_wilder


class TrendDip(Strategy):
    name = "trend_dip"

    def __init__(
        self,
        trend_fast: int = 9,
        trend_slow: int = 21,
        rsi_period: int = 14,
        oversold: float = 35,
        exit_level: float = 60,
    ):
        if trend_fast >= trend_slow:
            raise ValueError("trend_dip needs trend_fast < trend_slow")
        if oversold >= exit_level:
            raise ValueError("trend_dip needs oversold < exit_level")
        self.trend_fast = int(trend_fast)
        self.trend_slow = int(trend_slow)
        self.rsi_period = int(rsi_period)
        self.oversold = float(oversold)
        self.exit_level = float(exit_level)

    @property
    def warmup(self) -> int:
        # Need the slow SMA and the RSI both warmed up.
        return max(self.trend_slow, self.rsi_period + 1)

    def generate_signals(self, bars: pd.DataFrame) -> pd.Series:
        close = self._close(bars)

        sma_fast = close.rolling(self.trend_fast, min_periods=self.trend_fast).mean()
        sma_slow = close.rolling(self.trend_slow, min_periods=self.trend_slow).mean()
        uptrend = sma_fast > sma_slow  # trend filter / long permission

        rsi = rsi_wilder(close, self.rsi_period)

        # Stateful entry/exit via forward-fill of the last trigger (causal).
        entry = uptrend & (rsi < self.oversold)                  # dip inside an uptrend
        exit_ = (rsi > self.exit_level) | (~uptrend)             # recovered, or trend rolled over

        state = pd.Series(np.nan, index=close.index, dtype="float64")
        state[entry] = 1.0
        state[exit_] = 0.0
        # A bar can satisfy neither trigger -> position carries forward (hold).
        state = state.ffill()
        return _clean_signal(state, bars.index)
