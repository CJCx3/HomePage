"""RSI mean-reversion: buy oversold, exit when RSI recovers.

Enter long when RSI drops below `oversold`; hold until RSI rises above
`exit_level`, then go flat. It is stateful (a position persists between the
entry and exit triggers), implemented causally with forward-fill of the last
trigger — never with future data.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from .base import Strategy, _clean_signal


def rsi_wilder(close: pd.Series, period: int) -> pd.Series:
    """Wilder's RSI. Uses only past/current prices (EMA of gains/losses)."""
    delta = close.diff()
    gain = delta.clip(lower=0.0)
    loss = -delta.clip(upper=0.0)
    # Wilder smoothing == EMA with alpha = 1/period.
    avg_gain = gain.ewm(alpha=1.0 / period, min_periods=period, adjust=False).mean()
    avg_loss = loss.ewm(alpha=1.0 / period, min_periods=period, adjust=False).mean()
    rs = avg_gain / avg_loss.replace(0.0, np.nan)
    rsi = 100.0 - (100.0 / (1.0 + rs))
    # avg_loss == 0 (all gains) -> RSI 100; still-warming rows stay NaN.
    rsi = rsi.where(avg_loss != 0.0, 100.0)
    rsi[avg_gain.isna() | avg_loss.isna()] = np.nan
    return rsi


class RSIReversion(Strategy):
    name = "rsi_reversion"

    def __init__(self, period: int = 14, oversold: float = 30, exit_level: float = 55):
        if oversold >= exit_level:
            raise ValueError("rsi_reversion needs oversold < exit_level")
        self.period = int(period)
        self.oversold = float(oversold)
        self.exit_level = float(exit_level)

    @property
    def warmup(self) -> int:
        # RSI needs `period` diffs to warm up; +1 for the diff itself.
        return self.period + 1

    def generate_signals(self, bars: pd.DataFrame) -> pd.Series:
        close = self._close(bars)
        rsi = rsi_wilder(close, self.period)

        # Build a state series: 1 on an entry trigger, 0 on an exit trigger,
        # NaN otherwise, then forward-fill so the position persists between
        # triggers. ffill only ever looks backward -> causal.
        state = pd.Series(np.nan, index=close.index, dtype="float64")
        state[rsi < self.oversold] = 1.0
        state[rsi > self.exit_level] = 0.0
        state = state.ffill()
        return _clean_signal(state, bars.index)
