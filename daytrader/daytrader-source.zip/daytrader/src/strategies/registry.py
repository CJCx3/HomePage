"""name -> Strategy class, plus builders from config / active_strategy.json."""

from __future__ import annotations

from typing import Any

from .base import Strategy
from .breakout import Breakout
from .buy_and_hold import BuyAndHold
from .ma_crossover import MACrossover
from .rsi_reversion import RSIReversion
from .trend_dip import TrendDip

# The benchmark is always available but is added to candidate sets explicitly.
STRATEGIES: dict[str, type[Strategy]] = {
    "ma_crossover": MACrossover,
    "rsi_reversion": RSIReversion,
    "breakout": Breakout,
    "trend_dip": TrendDip,
    "buy_and_hold": BuyAndHold,
}

# Active (non-benchmark) strategies the selector ranks.
ACTIVE_STRATEGY_NAMES = ["ma_crossover", "rsi_reversion", "breakout", "trend_dip"]

BENCHMARK_NAME = "buy_and_hold"


def build_strategy(name: str, params: dict[str, Any] | None = None) -> Strategy:
    """Instantiate a strategy by name with a params dict."""
    if name not in STRATEGIES:
        raise KeyError(
            f"Unknown strategy {name!r}. Known: {', '.join(sorted(STRATEGIES))}"
        )
    params = params or {}
    return STRATEGIES[name](**params)


def build_candidates(config) -> list[Strategy]:
    """Build the full candidate set for selection: the active strategies from
    config.strategies plus the buy-and-hold benchmark."""
    candidates: list[Strategy] = []
    strat_params = config.strategies.model_dump()
    for name in ACTIVE_STRATEGY_NAMES:
        candidates.append(build_strategy(name, strat_params.get(name, {})))
    candidates.append(BuyAndHold())
    return candidates
