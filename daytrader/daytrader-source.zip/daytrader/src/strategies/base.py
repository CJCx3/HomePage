"""The Strategy interface — and the single most important rule in the system:
NO LOOKAHEAD.

A strategy turns a window of bars into a series of TARGET positions in {0, 1}
(long-only for now). The target at bar `t` may use ONLY information available
at the close of bar `t` — never t+1.

  * In BACKTEST, a change decided at bar t is filled at bar t+1's OPEN. The
    engine enforces this by shifting fills forward one bar; strategies must not
    "cheat" by peeking ahead inside generate_signals().
  * In LIVE, generate_signals() is handed only CLOSED bars, and the runner
    acts on the signal from the latest closed bar. The in-progress bar is never
    passed in, so there is nothing to peek at.

Every rolling/expanding computation here uses only past-and-current data
(pandas .rolling / .shift), which keeps the contract mechanically true.
"""

from __future__ import annotations

from abc import ABC, abstractmethod

import pandas as pd


class Strategy(ABC):
    #: registry name, e.g. "ma_crossover"
    name: str = "base"

    @property
    @abstractmethod
    def warmup(self) -> int:
        """Number of leading bars needed before the first *valid* signal.

        The live runner backfills at least this many bars (plus a buffer) on
        startup so it can act on the very first live bar instead of sitting
        idle for `warmup` bars.
        """

    @abstractmethod
    def generate_signals(self, bars: pd.DataFrame) -> pd.Series:
        """Return an int Series aligned to bars.index with values in {0, 1}.

        1 = target long (hold `max_position_notional` of the symbol),
        0 = target flat. Must be causal: signal[t] depends only on bars[:t+1].
        Bars whose indicators are not yet warmed up should be 0.
        """

    # -- shared helpers --------------------------------------------------------
    @staticmethod
    def _close(bars: pd.DataFrame) -> pd.Series:
        return bars["close"].astype(float)

    def __repr__(self) -> str:  # pragma: no cover - cosmetic
        return f"<Strategy {self.name} warmup={self.warmup}>"


def _clean_signal(signal: pd.Series, index: pd.Index) -> pd.Series:
    """Coerce a raw signal into the {0,1} int contract, aligned + gap-free."""
    return (
        signal.reindex(index)
        .fillna(0)
        .clip(0, 1)
        .round()
        .astype(int)
    )
