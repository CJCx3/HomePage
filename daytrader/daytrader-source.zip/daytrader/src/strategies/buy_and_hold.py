"""Buy-and-hold benchmark: always long.

This is the yardstick every selection is measured against. If no active
strategy beats buy-and-hold out-of-sample after costs, the selector reports
"NO EDGE FOUND" and promotes nothing. It is always in the candidate set and is
exempt from the min_trades filter (it makes exactly one trade by design).
"""

from __future__ import annotations

import pandas as pd

from .base import Strategy, _clean_signal


class BuyAndHold(Strategy):
    name = "buy_and_hold"

    def __init__(self, **_ignored):
        # Accepts and ignores any params so it can be built uniformly.
        pass

    @property
    def warmup(self) -> int:
        return 1

    def generate_signals(self, bars: pd.DataFrame) -> pd.Series:
        raw = pd.Series(1.0, index=bars.index)
        return _clean_signal(raw, bars.index)
