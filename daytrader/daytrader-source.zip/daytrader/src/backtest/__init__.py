"""Event-driven backtester + performance metrics."""
