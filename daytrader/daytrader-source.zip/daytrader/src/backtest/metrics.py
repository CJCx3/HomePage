"""Performance metrics computed from an equity curve + a trade log.

Annualization is resolution-aware: `periods_per_year` comes from the bar
resolution (252 for daily, far larger intraday). Using the daily factor on
intraday bars would inflate Sharpe by ~sqrt(bars_per_day) — a classic mistake.
"""

from __future__ import annotations

import math
from dataclasses import asdict, dataclass
from typing import Any

import numpy as np
import pandas as pd


@dataclass
class Metrics:
    total_return: float
    cagr: float
    sharpe: float
    sortino: float
    max_drawdown: float
    volatility_annual: float
    win_rate: float
    trade_count: int
    avg_trade_pnl: float
    exposure: float
    final_equity: float
    periods: int

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)

    def summary_line(self) -> str:
        return (
            f"ret={self.total_return:+.2%} cagr={self.cagr:+.2%} "
            f"sharpe={self.sharpe:.2f} maxDD={self.max_drawdown:.2%} "
            f"trades={self.trade_count} win={self.win_rate:.0%} "
            f"exposure={self.exposure:.0%}"
        )


def _safe_div(a: float, b: float) -> float:
    return a / b if b not in (0, 0.0) and not math.isnan(b) else 0.0


def compute_metrics(
    equity_curve: pd.Series,
    round_trips: list[dict],
    periods_per_year: float,
    exposure_fraction: float,
) -> Metrics:
    """Compute all metrics. `round_trips` is a list of closed trades each with
    a 'pnl' key. `exposure_fraction` is the share of bars spent in a position.
    """
    equity = equity_curve.astype(float).dropna()
    n = len(equity)
    if n < 2:
        return Metrics(0, 0, 0, 0, 0, 0, 0, len(round_trips), 0, exposure_fraction,
                       float(equity.iloc[-1]) if n else 0.0, n)

    start_eq = float(equity.iloc[0])
    final_eq = float(equity.iloc[-1])
    total_return = _safe_div(final_eq, start_eq) - 1.0 if start_eq else 0.0

    years = n / periods_per_year
    if years > 0 and start_eq > 0 and final_eq > 0:
        cagr = (final_eq / start_eq) ** (1.0 / years) - 1.0
    else:
        cagr = 0.0

    rets = equity.pct_change().dropna()
    mean_r = float(rets.mean())
    std_r = float(rets.std(ddof=1)) if len(rets) > 1 else 0.0
    ann = math.sqrt(periods_per_year)

    sharpe = _safe_div(mean_r, std_r) * ann
    volatility_annual = std_r * ann

    downside = rets[rets < 0]
    downside_std = float(downside.std(ddof=1)) if len(downside) > 1 else 0.0
    sortino = _safe_div(mean_r, downside_std) * ann

    running_max = equity.cummax()
    drawdown = equity / running_max - 1.0
    max_drawdown = float(drawdown.min())

    trade_count = len(round_trips)
    if trade_count:
        pnls = np.array([t["pnl"] for t in round_trips], dtype=float)
        win_rate = float((pnls > 0).mean())
        avg_trade_pnl = float(pnls.mean())
    else:
        win_rate = 0.0
        avg_trade_pnl = 0.0

    return Metrics(
        total_return=total_return,
        cagr=cagr,
        sharpe=sharpe,
        sortino=sortino,
        max_drawdown=max_drawdown,
        volatility_annual=volatility_annual,
        win_rate=win_rate,
        trade_count=trade_count,
        avg_trade_pnl=avg_trade_pnl,
        exposure=exposure_fraction,
        final_equity=final_eq,
        periods=n,
    )
