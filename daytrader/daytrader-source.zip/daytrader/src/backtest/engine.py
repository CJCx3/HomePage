"""Event-driven backtester with a strict next-bar-open fill rule.

The core anti-lookahead guarantee:

    A target position decided at the CLOSE of bar t is executed at the OPEN of
    bar t+1. Concretely, `prev_target` (the decision carried out of bar t-1) is
    what gets reconciled at bar t's open. A signal on the final bar therefore
    never trades — there is no next bar to fill it.

Sizing is full-equity, long-only, fractional: signal 1 => all equity in the
symbol, signal 0 => all cash. That makes buy-and-hold's equity curve exactly
the symbol's price return, which is the honest benchmark for comparison.

Costs are ALWAYS modeled: `slippage_bps` moves the fill against you and
`commission_per_trade` is charged on every execution. Zero-cost results are
fiction (see spec section 1).
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
import pandas as pd

REQUIRED_COLUMNS = ("open", "high", "low", "close")


@dataclass
class BacktestResult:
    equity_curve: pd.Series            # mark-to-market equity at each bar close
    position_series: pd.Series         # shares held during each bar
    trades: list[dict] = field(default_factory=list)        # every fill
    round_trips: list[dict] = field(default_factory=list)   # closed buy->sell pairs
    starting_cash: float = 0.0
    exposure_fraction: float = 0.0

    @property
    def final_equity(self) -> float:
        return float(self.equity_curve.iloc[-1]) if len(self.equity_curve) else self.starting_cash


def run_backtest(
    bars: pd.DataFrame,
    signals: pd.Series,
    starting_cash: float = 10_000.0,
    commission_per_trade: float = 0.0,
    slippage_bps: float = 5.0,
) -> BacktestResult:
    """Run the event-driven backtest.

    Parameters
    ----------
    bars : DataFrame with open/high/low/close (index = timestamps).
    signals : Series of target positions in {0,1} aligned to bars.index. The
        signal at bar t is acted on at bar t+1's open (this function shifts it).
    """
    missing = [c for c in REQUIRED_COLUMNS if c not in bars.columns]
    if missing:
        raise ValueError(f"bars missing required columns: {missing}")
    if len(bars) == 0:
        raise ValueError("cannot backtest on an empty bar set")

    bars = bars.sort_index()
    signals = signals.reindex(bars.index).fillna(0).clip(0, 1).round().astype(int)

    opens = bars["open"].to_numpy(dtype=float)
    closes = bars["close"].to_numpy(dtype=float)
    targets = signals.to_numpy(dtype=int)
    n = len(bars)

    slip = slippage_bps / 10_000.0

    cash = float(starting_cash)
    shares = 0.0
    entry_price = 0.0  # slippage-adjusted price at which the open lot was bought
    entry_cost = 0.0   # cash spent to open the lot (incl. commission)

    equity = np.empty(n, dtype=float)
    pos_held = np.zeros(n, dtype=float)
    trades: list[dict] = []
    round_trips: list[dict] = []

    prev_target = 0  # nothing decided before the first bar => start flat
    bars_in_position = 0

    for i in range(n):
        o = opens[i]
        c = closes[i]
        ts = bars.index[i]

        # --- reconcile at THIS bar's open to the decision from the PRIOR bar ---
        if prev_target == 1 and shares == 0.0 and o > 0:
            # BUY: pay slippage up, commission flat. Invest all available cash.
            fill = o * (1.0 + slip)
            investable = cash - commission_per_trade
            if investable > 0:
                bought = investable / fill
                cash -= bought * fill + commission_per_trade
                shares = bought
                entry_price = fill
                entry_cost = bought * fill + commission_per_trade
                trades.append(dict(timestamp=ts, side="buy", price=fill,
                                   shares=bought, commission=commission_per_trade,
                                   cash=cash))
        elif prev_target == 0 and shares > 0.0:
            # SELL: pay slippage down, commission flat. Go fully to cash.
            fill = o * (1.0 - slip)
            proceeds = shares * fill - commission_per_trade
            cash += proceeds
            pnl = proceeds - entry_cost
            trades.append(dict(timestamp=ts, side="sell", price=fill,
                               shares=shares, commission=commission_per_trade,
                               cash=cash))
            round_trips.append(dict(exit_time=ts, exit_price=fill,
                                    entry_price=entry_price, shares=shares,
                                    pnl=pnl))
            shares = 0.0
            entry_price = 0.0
            entry_cost = 0.0

        # --- mark-to-market at this bar's close ---
        equity[i] = cash + shares * c
        pos_held[i] = shares
        if shares > 0:
            bars_in_position += 1

        # decision made at THIS close is executed at NEXT bar's open
        prev_target = int(targets[i])

    equity_series = pd.Series(equity, index=bars.index, name="equity")
    position_series = pd.Series(pos_held, index=bars.index, name="shares")
    exposure = bars_in_position / n if n else 0.0

    return BacktestResult(
        equity_curve=equity_series,
        position_series=position_series,
        trades=trades,
        round_trips=round_trips,
        starting_cash=float(starting_cash),
        exposure_fraction=exposure,
    )
