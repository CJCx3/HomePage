"""Risk controls — the mandatory safety layer.

The kill switch cannot be disabled; only its dollar threshold is configurable.

Kill-switch semantics (implemented exactly per build pack section H):
  * At each market OPEN, store the day's STARTING equity in state/ as the
    session P&L baseline.
  * TRIP when `starting_equity - current_equity >= max_daily_loss`: flatten via
    broker.close_all(), persist `tripped: true`, and stop trading.
  * `tripped` PERSISTS across restarts and is cleared ONLY by
    scripts/reset_killswitch.py. It does NOT auto-clear the next day — the
    operator must acknowledge.

Other controls: max notional per position, optional per-trade stop-loss,
optional end-of-day flat-out (all session timing in America/New_York).
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional
from zoneinfo import ZoneInfo

from ..logging_util import get_logger

log = get_logger("daytrader.risk")

NY = ZoneInfo("America/New_York")
PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
DEFAULT_STATE_DIR = PROJECT_ROOT / "state"
SESSION_FILE = "session.json"


@dataclass
class SessionState:
    session_date: Optional[str] = None      # NY date of the baseline (YYYY-MM-DD)
    starting_equity: Optional[float] = None  # session P&L baseline
    tripped: bool = False
    tripped_at: Optional[str] = None
    tripped_reason: Optional[str] = None

    def to_dict(self) -> dict:
        return {
            "session_date": self.session_date,
            "starting_equity": self.starting_equity,
            "tripped": self.tripped,
            "tripped_at": self.tripped_at,
            "tripped_reason": self.tripped_reason,
        }


class RiskManager:
    def __init__(self, config, state_dir: str | Path | None = None):
        self.config = config
        self.risk = config.risk
        self.state_dir = Path(state_dir) if state_dir else DEFAULT_STATE_DIR
        self.state_dir.mkdir(parents=True, exist_ok=True)
        self.state_path = self.state_dir / SESSION_FILE
        self.state = self._load()

    # -- persistence -----------------------------------------------------------
    def _load(self) -> SessionState:
        if self.state_path.exists():
            try:
                raw = json.loads(self.state_path.read_text(encoding="utf-8"))
                return SessionState(**{k: raw.get(k) for k in SessionState().to_dict()})
            except Exception as e:  # corrupt state must not silently reset safety
                log.warning("could not parse %s (%s); starting fresh session state",
                            self.state_path, e)
        return SessionState()

    def _save(self) -> None:
        self.state_path.write_text(json.dumps(self.state.to_dict(), indent=2), encoding="utf-8")

    # -- session baseline ------------------------------------------------------
    def start_session(self, current_equity: float, now: Optional[datetime] = None) -> None:
        """Establish (or roll to) today's baseline equity.

        A new NY calendar day sets a fresh baseline. Crucially, a new day does
        NOT clear a tripped kill switch — the operator must reset it manually.
        """
        now = now or datetime.now(NY)
        ny_date = now.astimezone(NY).strftime("%Y-%m-%d")
        if self.state.session_date != ny_date or self.state.starting_equity is None:
            prev_tripped = self.state.tripped
            self.state.session_date = ny_date
            self.state.starting_equity = float(current_equity)
            # preserve tripped across the day boundary (do NOT auto-clear)
            self.state.tripped = prev_tripped
            self._save()
            log.info("session baseline set: date=%s starting_equity=%.2f tripped=%s",
                     ny_date, current_equity, prev_tripped)
        # else: same-day restart — keep the original baseline (the day's open).

    # -- kill switch -----------------------------------------------------------
    def is_tripped(self) -> bool:
        return bool(self.state.tripped)

    def session_loss(self, current_equity: float) -> float:
        """Positive number = how much the session is DOWN from the baseline."""
        base = self.state.starting_equity
        if base is None:
            return 0.0
        return float(base) - float(current_equity)

    def would_trip(self, current_equity: float) -> bool:
        return self.session_loss(current_equity) >= self.risk.max_daily_loss

    def trip(self, reason: str, now: Optional[datetime] = None) -> None:
        now = now or datetime.now(NY)
        self.state.tripped = True
        self.state.tripped_at = now.astimezone(NY).isoformat()
        self.state.tripped_reason = reason
        self._save()
        log.error("KILL SWITCH TRIPPED: %s", reason)

    def enforce(self, current_equity: float, broker=None, now: Optional[datetime] = None) -> bool:
        """Evaluate the daily-loss rule. If breached and not already tripped,
        trip + flatten. Returns True if the kill switch is (now) tripped."""
        if self.is_tripped():
            return True
        if self.would_trip(current_equity):
            loss = self.session_loss(current_equity)
            reason = (f"session loss ${loss:.2f} >= max_daily_loss "
                      f"${self.risk.max_daily_loss:.2f}")
            self.trip(reason, now=now)
            if broker is not None:
                try:
                    broker.close_all()
                    log.error("kill switch flattened all positions")
                except Exception as e:  # never let flatten failure crash the loop
                    log.error("kill switch flatten FAILED (manual intervention needed): %s", e)
            return True
        return False

    def reset(self) -> None:
        """Clear a tripped kill switch. Only reset_killswitch.py should call this."""
        self.state.tripped = False
        self.state.tripped_at = None
        self.state.tripped_reason = None
        self._save()
        log.info("kill switch reset — trading may resume")

    # -- sizing / stops / EOD --------------------------------------------------
    def clamp_notional(self, desired_notional: float) -> float:
        """Never size a position above max_position_notional."""
        return float(min(desired_notional, self.risk.max_position_notional))

    def stop_loss_hit(self, entry_price: float, current_price: float) -> bool:
        pct = self.risk.stop_loss_pct
        if pct is None or entry_price <= 0:
            return False
        return current_price <= entry_price * (1.0 - pct)

    def should_eod_flat(
        self,
        next_close_utc: datetime,
        now: Optional[datetime] = None,
        buffer_minutes: int = 5,
    ) -> bool:
        """True if EOD flat-out is on and we are within `buffer_minutes` of the
        session close (handles half-days/holidays because next_close comes from
        Alpaca's calendar-aware clock)."""
        if not self.risk.eod_flat:
            return False
        now = now or datetime.now(tz=next_close_utc.tzinfo)
        return now >= (next_close_utc - timedelta(minutes=buffer_minutes))
