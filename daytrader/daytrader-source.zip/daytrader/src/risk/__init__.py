"""Risk controls: mandatory kill switch, notional caps, stops, EOD flat."""
