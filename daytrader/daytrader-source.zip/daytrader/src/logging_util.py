"""Tiny logging helper: console + optional append-only file in reports/."""

from __future__ import annotations

import logging
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
REPORTS_DIR = PROJECT_ROOT / "reports"

_CONFIGURED: set[str] = set()


def _force_utf8_console() -> None:
    """Windows consoles default to cp1252 and crash on non-ASCII output.
    Reconfigure stdout/stderr in place to UTF-8 so logs/prints never blow up
    (reconfigure mutates the existing stream objects, so logging handlers that
    reference sys.stderr are covered too)."""
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass


_force_utf8_console()


def get_logger(name: str = "daytrader", logfile: str | None = None) -> logging.Logger:
    logger = logging.getLogger(name)
    if name in _CONFIGURED:
        return logger
    logger.setLevel(logging.INFO)
    logger.propagate = False

    fmt = logging.Formatter("%(asctime)s  %(levelname)-5s  %(message)s", "%Y-%m-%d %H:%M:%S")
    ch = logging.StreamHandler()
    ch.setFormatter(fmt)
    logger.addHandler(ch)

    if logfile:
        REPORTS_DIR.mkdir(parents=True, exist_ok=True)
        fh = logging.FileHandler(REPORTS_DIR / logfile, encoding="utf-8")
        fh.setFormatter(fmt)
        logger.addHandler(fh)

    _CONFIGURED.add(name)
    return logger
