# daytrader

A small, honest day-trading bot with four modes — `backtest`, `select`,
**`paper`** (default), and `live` — a live trading runner, hot-swappable
strategies, and mandatory risk controls including a max-daily-loss kill switch.

**New here? Read [SETUP.md](SETUP.md).** It walks through installation, keys,
running the bot, changing strategies, configuring risk, and going live — in
plain language.

> Not financial advice. Risk only money you can afford to lose. A backtest is
> not a prediction, and automating a losing strategy loses money faster.

## What it does

- **Defaults to paper mode.** Real-money `live` mode refuses to start unless you
  set `i_understand_live_risk: true` in `config.yaml`.
- **Kill switch is mandatory and on.** If the session loss reaches
  `risk.max_daily_loss`, it flattens everything, halts, and stays tripped until
  you reset it (`scripts/reset_killswitch.py`).
- **Costs are always modeled** (commission + slippage) in every backtest and
  selection. Zero-cost results are fiction.
- **Every comparison includes buy-and-hold.** If nothing beats it out-of-sample
  after costs, the selector reports **"NO EDGE FOUND"** and promotes nothing.
- **Notional (dollar) sizing** so it trades at any share price (no "rounds to 0
  shares and never trades" trap).
- **America/New_York** session logic via Alpaca's calendar-aware clock; UTC bar
  timestamps are converted correctly.

## Quick start

```bash
python -m venv venv && venv\Scripts\activate      # mac/linux: source venv/bin/activate
pip install -r requirements.txt

# key-free research (yfinance daily):
python scripts/run_backtest.py  --strategy ma_crossover --source yfinance --resolution 1Day --start 2018-01-01
python scripts/run_selection.py --source yfinance --resolution 1Day --start 2018-01-01

# paper trading (needs free Alpaca paper keys in .env — see SETUP.md):
python scripts/preflight.py        # run this FIRST
python scripts/run_live.py         # during US market hours
```

## Modes

| Mode | Data | Orders | Purpose |
|---|---|---|---|
| `backtest` | historical | none | evaluate one strategy over history |
| `select` | historical | none | rank all candidates, write the active strategy |
| `paper` *(default)* | real-time | simulated (Alpaca paper) | run the full bot with no risk |
| `live` | real-time | **real (Alpaca live)** | real money — requires `i_understand_live_risk: true` |

Set the mode in `config.yaml`.

## Scripts

| Command | What it does |
|---|---|
| `scripts/preflight.py` | 7 PASS/FAIL checks; run before trading (exits non-zero on any fail). |
| `scripts/run_backtest.py` | Backtest one strategy vs buy-and-hold; writes an equity PNG. |
| `scripts/run_selection.py` | Rank candidates OOS; promote a winner or report NO EDGE FOUND. |
| `scripts/set_strategy.py` | Manually set the active strategy (hot-reloaded next cycle). |
| `scripts/run_live.py` | Start the trading loop (paper/live per config). |
| `scripts/reset_killswitch.py` | Clear a tripped kill switch. |

## Strategies

`ma_crossover` (SMA fast/slow), `rsi_reversion` (RSI oversold/exit),
`breakout` (Donchian N-bar high/low), and `buy_and_hold` (the benchmark, always
in the candidate set). All are long-only, target positions in `{0, 1}`, and
obey a strict **no-lookahead** contract: a decision at bar *t* is filled at bar
*t+1*'s open in backtests, and computed only from **closed** bars when live.

## Project layout

```
config.yaml            active_strategy.json   .env.example   requirements.txt
src/   config, timeframes, data/, strategies/, backtest/, selection/,
       execution/, live/, risk/, reporting/
scripts/  preflight, run_backtest, run_selection, set_strategy, run_live, reset_killswitch
tests/    test_metrics, test_engine, test_risk
state/    reports/   data/     (runtime output; git-ignored)
```

## Tests

```bash
python -m pytest -q
```

Covers the metrics math, the engine's next-bar-open fill (no-lookahead) and
cost modeling, and the kill switch (trip → flatten → persist → reset), including
an end-to-end runner test.

## Tech

Python 3.11+, [`alpaca-py`](https://github.com/alpacahq/alpaca-py) (current SDK
— not the deprecated `alpaca-trade-api`), `yfinance` for key-free history,
`pandas`, `numpy`, `matplotlib`, `pydantic`, `pyyaml`, `python-dotenv`, `pytest`.

See **[SETUP.md](SETUP.md)** for everything else, including the free-feed (IEX)
limitation and the daily-bar fallback.
