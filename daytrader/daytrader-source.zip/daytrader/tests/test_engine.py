"""Engine correctness — the anti-lookahead guarantee and honest cost modeling."""

import pandas as pd

from src.backtest.engine import run_backtest


def _bars(opens, closes):
    n = len(opens)
    idx = pd.date_range("2021-01-04", periods=n, freq="D", tz="UTC")
    return pd.DataFrame(
        {
            "open": opens,
            "high": [max(o, c) + 1 for o, c in zip(opens, closes)],
            "low": [min(o, c) - 1 for o, c in zip(opens, closes)],
            "close": closes,
        },
        index=idx,
    )


def test_fill_is_next_bar_open():
    """A signal decided at bar t must fill at bar t+1's OPEN, not bar t."""
    opens = [100.0, 110.0, 120.0, 130.0, 140.0]
    closes = [105.0, 115.0, 125.0, 135.0, 145.0]
    bars = _bars(opens, closes)
    # Decide LONG at bar index 2 (close), flat again at index 3.
    signals = pd.Series([0, 0, 1, 0, 0], index=bars.index)

    res = run_backtest(bars, signals, starting_cash=10_000,
                       commission_per_trade=0.0, slippage_bps=0.0)

    assert len(res.trades) == 2
    buy, sell = res.trades
    # BUY fills at bar index 3's OPEN (130), NOT bar 2's price.
    assert buy["side"] == "buy"
    assert buy["timestamp"] == bars.index[3]
    assert abs(buy["price"] - 130.0) < 1e-9
    # SELL fills at bar index 4's OPEN (140).
    assert sell["side"] == "sell"
    assert sell["timestamp"] == bars.index[4]
    assert abs(sell["price"] - 140.0) < 1e-9


def test_signal_on_last_bar_never_trades():
    """No next bar exists to fill the last bar's decision -> no trade."""
    opens = [100.0, 101.0, 102.0, 103.0]
    closes = [100.5, 101.5, 102.5, 103.5]
    bars = _bars(opens, closes)
    signals = pd.Series([0, 0, 0, 1], index=bars.index)  # decided only on the last bar

    res = run_backtest(bars, signals, starting_cash=10_000,
                       commission_per_trade=0.0, slippage_bps=0.0)
    assert res.trades == []
    assert abs(res.final_equity - 10_000) < 1e-9  # never invested


def test_costs_reduce_returns():
    """Modeled slippage/commission must measurably lower final equity."""
    opens = [100.0, 101.0, 102.0, 103.0, 104.0]
    closes = [100.5, 101.5, 102.5, 103.5, 104.5]
    bars = _bars(opens, closes)
    signals = pd.Series([1, 1, 1, 1, 1], index=bars.index)  # always long

    zero_cost = run_backtest(bars, signals, 10_000, commission_per_trade=0.0, slippage_bps=0.0)
    with_slip = run_backtest(bars, signals, 10_000, commission_per_trade=0.0, slippage_bps=5.0)
    with_comm = run_backtest(bars, signals, 10_000, commission_per_trade=1.0, slippage_bps=0.0)

    assert with_slip.final_equity < zero_cost.final_equity
    assert with_comm.final_equity < zero_cost.final_equity


def test_buy_and_hold_matches_price_return():
    """Full-equity buy-and-hold (zero cost) should equal the asset's return."""
    opens = [100.0, 100.0, 100.0]
    closes = [100.0, 110.0, 120.0]
    bars = _bars(opens, closes)
    signals = pd.Series([1, 1, 1], index=bars.index)
    res = run_backtest(bars, signals, 10_000, 0.0, 0.0)
    # bought at first open (100), marked at last close (120) -> +20%
    assert abs(res.final_equity - 12_000) < 1e-6


def test_empty_bars_raises():
    import pytest
    with pytest.raises(ValueError):
        run_backtest(pd.DataFrame(columns=["open", "high", "low", "close"]),
                     pd.Series(dtype=int))
