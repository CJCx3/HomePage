"""Strategy behavior — focus on the trend_dip hybrid's regime filter."""

import numpy as np
import pandas as pd

from src.strategies.trend_dip import TrendDip
from src.strategies.registry import build_strategy, build_candidates
from src.config import load_config


def _bars_from_close(close):
    idx = pd.date_range("2024-01-02", periods=len(close), freq="5min", tz="UTC")
    close = pd.Series(close, index=idx, dtype=float)
    return pd.DataFrame({"open": close, "high": close + 0.5,
                         "low": close - 0.5, "close": close}, index=idx)


def test_trend_dip_signals_are_binary_and_causal():
    rng = np.random.default_rng(1)
    close = 100 + np.cumsum(rng.normal(0, 0.5, 300))
    bars = _bars_from_close(close)
    sig = TrendDip().generate_signals(bars)
    assert set(sig.unique()).issubset({0, 1})
    assert sig.index.equals(bars.index)
    # warmup bars must be flat (indicators not ready yet)
    assert sig.iloc[0] == 0


def test_trend_dip_does_not_buy_dips_in_a_downtrend():
    """The falling-knife guard: in a steady downtrend, RSI gets very oversold,
    but the trend filter must keep it FLAT (never buys the dip)."""
    close = np.linspace(200, 100, 120)  # relentless downtrend -> deeply oversold RSI
    bars = _bars_from_close(close)
    sig = TrendDip(trend_fast=9, trend_slow=21, rsi_period=14, oversold=35, exit_level=60)\
        .generate_signals(bars)
    assert sig.sum() == 0  # never long during the downtrend


def test_trend_dip_can_go_long_on_a_dip_within_an_uptrend():
    """Uptrend overall, with a temporary dip that pushes RSI down -> it should
    take at least one long position (unlike the downtrend case)."""
    # rising baseline with a pronounced mid dip, then recovery + continued rise
    base = np.linspace(100, 140, 160)
    dip = np.zeros(160)
    dip[70:85] = -np.hanning(30)[:15] * 12  # a temporary slump inside the uptrend
    close = base + dip
    bars = _bars_from_close(close)
    sig = TrendDip(trend_fast=9, trend_slow=21, rsi_period=10, oversold=40, exit_level=60)\
        .generate_signals(bars)
    assert sig.sum() > 0  # it found a dip-in-uptrend to buy


def test_trend_dip_is_in_candidate_set_and_buildable_from_config():
    cfg = load_config()
    names = [s.name for s in build_candidates(cfg)]
    assert "trend_dip" in names
    s = build_strategy("trend_dip", {"trend_fast": 5, "trend_slow": 20,
                                      "rsi_period": 14, "oversold": 30, "exit_level": 65})
    assert s.warmup == 20
