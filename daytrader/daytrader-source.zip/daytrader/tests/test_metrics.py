"""Metrics behave as expected on known equity curves."""

import numpy as np
import pandas as pd

from src.backtest.metrics import compute_metrics
from src.timeframes import parse_resolution


def _curve(values):
    idx = pd.date_range("2020-01-01", periods=len(values), freq="D", tz="UTC")
    return pd.Series(values, index=idx, dtype=float)


def test_total_return_simple():
    eq = _curve([100, 110, 121])  # +21% overall
    m = compute_metrics(eq, [], periods_per_year=252, exposure_fraction=1.0)
    assert m.total_return == 0 or abs(m.total_return - 0.21) < 1e-9
    assert abs(m.final_equity - 121.0) < 1e-9


def test_max_drawdown():
    # up to 200 then down to 150 -> worst drawdown = -25% from the 200 peak.
    eq = _curve([100, 200, 150, 180])
    m = compute_metrics(eq, [], periods_per_year=252, exposure_fraction=1.0)
    assert abs(m.max_drawdown - (-0.25)) < 1e-9


def test_no_drawdown_when_monotonic():
    eq = _curve([100, 101, 102, 103])
    m = compute_metrics(eq, [], periods_per_year=252, exposure_fraction=1.0)
    assert m.max_drawdown == 0.0
    assert m.total_return > 0


def test_sharpe_sign_and_zero_vol():
    up = _curve([100 * (1.001 ** i) for i in range(50)])   # steady gains
    m_up = compute_metrics(up, [], periods_per_year=252, exposure_fraction=1.0)
    assert m_up.sharpe > 0

    flat = _curve([100, 100, 100, 100])  # zero volatility -> guarded to 0
    m_flat = compute_metrics(flat, [], periods_per_year=252, exposure_fraction=1.0)
    assert m_flat.sharpe == 0.0


def test_win_rate_and_trade_count():
    rts = [{"pnl": 10.0}, {"pnl": -5.0}, {"pnl": 3.0}, {"pnl": -1.0}]
    eq = _curve([100, 105, 103, 108])
    m = compute_metrics(eq, rts, periods_per_year=252, exposure_fraction=0.5)
    assert m.trade_count == 4
    assert abs(m.win_rate - 0.5) < 1e-9
    assert abs(m.avg_trade_pnl - (10 - 5 + 3 - 1) / 4) < 1e-9
    assert m.exposure == 0.5


def test_annualization_is_resolution_aware():
    # Same per-bar returns annualize to a LARGER Sharpe intraday than daily,
    # because there are far more bars per year. Guards the classic mistake.
    rng = np.random.default_rng(0)
    rets = rng.normal(0.0005, 0.01, 400)
    eq_vals = 100 * np.cumprod(1 + rets)
    eq = _curve(eq_vals)

    daily = compute_metrics(eq, [], parse_resolution("1Day").periods_per_year, 1.0)
    intraday = compute_metrics(eq, [], parse_resolution("5Min").periods_per_year, 1.0)
    assert intraday.sharpe > daily.sharpe
