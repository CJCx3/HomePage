"""Data loader / feed tolerate sparse + empty bars without crashing.

Covers build pack section K: "Loader/feed tolerate an empty/sparse intraday bar
without crashing (forced-empty-bar test)."
"""

import numpy as np
import pandas as pd
import pytest

from src.data.loader import _normalize
from src.timeframes import parse_resolution

OHLCV = ["open", "high", "low", "close", "volume"]


def test_normalize_drops_empty_and_nan_bars():
    idx = pd.date_range("2024-01-02 09:30", periods=5, freq="5min", tz="UTC")
    df = pd.DataFrame(
        {
            "Open": [100.0, np.nan, 102.0, 103.0, np.nan],   # 2 empty/gap bars
            "High": [101.0, np.nan, 103.0, 104.0, np.nan],
            "Low": [99.0, np.nan, 101.0, 102.0, np.nan],
            "Close": [100.5, np.nan, 102.5, 103.5, np.nan],
            "Volume": [1000, 0, 2000, 1500, 0],
        },
        index=idx,
    )
    out = _normalize(df, "SPY")
    assert list(out.columns) == OHLCV
    assert len(out) == 3                     # the 2 NaN bars were dropped, not fatal
    assert not out[["open", "high", "low", "close"]].isna().any().any()


def test_normalize_handles_completely_empty_frame():
    out = _normalize(pd.DataFrame(), "SPY")
    assert list(out.columns) == OHLCV
    assert len(out) == 0                      # empty in -> empty out, no crash


def test_normalize_flattens_yfinance_multiindex_columns():
    idx = pd.date_range("2024-01-02", periods=3, freq="D", tz="UTC")
    cols = pd.MultiIndex.from_product([["Open", "High", "Low", "Close", "Volume"], ["SPY"]])
    df = pd.DataFrame(
        [[100, 101, 99, 100.5, 1000], [101, 102, 100, 101.5, 1100], [102, 103, 101, 102.5, 1200]],
        index=idx, columns=cols,
    )
    out = _normalize(df, "SPY")
    assert list(out.columns) == OHLCV
    assert len(out) == 3


def test_live_feed_excludes_in_progress_bar():
    """The most recent bar whose period has not finished must be dropped, so a
    live signal is never computed from an in-progress bar (no lookahead)."""
    try:
        from src.data.live_feed import LiveFeed
    except Exception:
        pytest.skip("alpaca-py not importable")

    res = parse_resolution("5Min")
    feed = LiveFeed("SPY", res, "dummy", "dummy")  # no network call on construction

    now = pd.Timestamp("2024-06-03 14:32:00", tz="UTC")  # 14:30 bar is still forming
    idx = pd.DatetimeIndex(
        ["2024-06-03 14:20", "2024-06-03 14:25", "2024-06-03 14:30"], tz="UTC"
    )
    df = pd.DataFrame(
        {"open": [1, 2, 3], "high": [1, 2, 3], "low": [1, 2, 3],
         "close": [1, 2, 3], "volume": [10, 10, 10]},
        index=idx, dtype=float,
    )
    feed._fetch = lambda start, end: df  # inject bars, no network

    out = feed.get_closed_bars(5, now=now.to_pydatetime())
    # 14:30 bar closes at 14:35 > 14:32 -> excluded; last CLOSED bar is 14:25.
    assert out.index[-1] == pd.Timestamp("2024-06-03 14:25", tz="UTC")
    assert len(out) == 2


def test_live_feed_daily_excludes_todays_forming_bar():
    """Daily bars are stamped at ~midnight UTC; the feed must exclude TODAY's
    still-forming session and use the last COMPLETED day (no lookahead)."""
    try:
        from src.data.live_feed import LiveFeed
    except Exception:
        pytest.skip("alpaca-py not importable")
    res = parse_resolution("1Day")
    feed = LiveFeed("SPY", res, "dummy", "dummy")

    now = pd.Timestamp("2026-08-10 15:37:00", tz="UTC")  # Mon, market open
    # Alpaca-style daily bars stamped at 04:00 UTC (midnight ET) of each date.
    idx = pd.DatetimeIndex(["2026-08-06 04:00", "2026-08-07 04:00", "2026-08-10 04:00"], tz="UTC")
    df = pd.DataFrame({"open": [1, 2, 3], "high": [1, 2, 3], "low": [1, 2, 3],
                       "close": [1, 2, 3], "volume": [10, 10, 10]}, index=idx, dtype=float)
    feed._fetch = lambda start, end: df

    out = feed.get_closed_bars(5, now=now.to_pydatetime())
    # today's (2026-08-10) forming bar dropped; last completed = Fri 2026-08-07
    assert out.index[-1] == pd.Timestamp("2026-08-07 04:00", tz="UTC")
    assert len(out) == 2


def test_live_feed_empty_fetch_is_not_fatal():
    try:
        from src.data.live_feed import LiveFeed
    except Exception:
        pytest.skip("alpaca-py not importable")
    res = parse_resolution("5Min")
    feed = LiveFeed("SPY", res, "dummy", "dummy")
    feed._fetch = lambda start, end: pd.DataFrame(columns=OHLCV)
    out = feed.get_closed_bars(5)
    assert len(out) == 0  # empty feed -> empty window, no exception
