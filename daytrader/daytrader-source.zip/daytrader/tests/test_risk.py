"""Risk controls — the mandatory kill switch and its exact semantics.

Covers spec section 8 + build pack section H:
  * trips when session loss >= max_daily_loss
  * flattens via broker.close_all()
  * persists across "restart" (a fresh RiskManager reads the tripped flag)
  * does NOT auto-clear the next day
  * cleared only by reset()
Plus a runner-level test proving the loop HALTS + FLATTENS + refuses to trade.
"""

from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo

import pandas as pd

from src.config import Config
from src.execution.broker import AccountSnapshot, ClockSnapshot
from src.live.runner import LiveRunner
from src.risk.controls import RiskManager

NY = ZoneInfo("America/New_York")


def make_config(max_daily_loss=100.0, stop_loss_pct=None, eod_flat=False, resolution="1Day"):
    return Config(
        mode="paper",
        i_understand_live_risk=False,
        symbol="SPY",
        bar_resolution=resolution,
        risk={
            "max_daily_loss": max_daily_loss,
            "max_position_notional": 1000,
            "stop_loss_pct": stop_loss_pct,
            "eod_flat": eod_flat,
        },
        strategies={
            "ma_crossover": {"fast": 9, "slow": 21},
            "rsi_reversion": {"period": 14, "oversold": 30, "exit_level": 55},
            "breakout": {"lookback": 20},
        },
    )


class FakeBroker:
    """Minimal broker for tests. Returns start equity on the first account call
    (startup baseline) and a lower equity afterwards (to trip the kill switch)."""

    def __init__(self, start_equity=10_000.0, cycle_equity=9_800.0, is_open=True, pos=0.0,
                 orphans=None):
        self.start_equity = start_equity
        self.cycle_equity = cycle_equity
        self.is_open = is_open
        self._pos = pos
        self._acct_calls = 0
        self.close_all_calls = 0
        self.close_position_calls = 0
        self.closed_symbols = []
        self.buy_calls = 0
        self._orphans = orphans or []  # list of (symbol, qty)

    def get_all_positions(self):
        from types import SimpleNamespace
        return [SimpleNamespace(symbol=s, qty=q) for (s, q) in self._orphans]

    def get_account(self):
        self._acct_calls += 1
        eq = self.start_equity if self._acct_calls == 1 else self.cycle_equity
        return AccountSnapshot(equity=eq, cash=eq, buying_power=eq * 2, last_equity=self.start_equity)

    def get_equity(self):
        return self.get_account().equity

    def get_clock(self):
        now = datetime(2030, 6, 3, 15, 0, tzinfo=timezone.utc)
        return ClockSnapshot(timestamp=now, is_open=self.is_open,
                             next_open=now + timedelta(days=1),
                             next_close=now + timedelta(hours=1))

    def get_position(self, symbol):
        return self._pos

    def get_position_details(self, symbol):
        return None

    def close_all(self):
        self.close_all_calls += 1
        self._pos = 0.0

    def close_position(self, symbol):
        self.close_position_calls += 1
        self.closed_symbols.append(symbol)
        self._orphans = [(s, q) for (s, q) in self._orphans if s != symbol]
        self._pos = 0.0

    def submit_notional(self, symbol, side, notional):
        self.buy_calls += 1


class FakeFeed:
    def __init__(self, bars):
        self.bars = bars

    def backfill(self, warmup, now=None):
        return self.bars

    def get_closed_bars(self, warmup, now=None):
        return self.bars

    def seconds_to_next_bar_close(self, now=None):
        return 0.0


def _tiny_bars(n=30):
    idx = pd.date_range("2030-06-01", periods=n, freq="D", tz="UTC")
    return pd.DataFrame(
        {"open": range(100, 100 + n), "high": range(101, 101 + n),
         "low": range(99, 99 + n), "close": range(100, 100 + n)},
        index=idx, dtype=float,
    )


# -- RiskManager-level semantics ----------------------------------------------
def test_killswitch_trips_flattens_persists_and_resets(tmp_path):
    cfg = make_config(max_daily_loss=100.0)
    rm = RiskManager(cfg, state_dir=tmp_path)
    rm.start_session(10_000.0, now=datetime(2030, 6, 3, 10, 0, tzinfo=NY))
    assert not rm.is_tripped()

    broker = FakeBroker()
    # loss of 50 < 100 -> no trip
    assert rm.enforce(9_950.0, broker) is False
    assert not rm.is_tripped()
    assert broker.close_all_calls == 0

    # loss of 150 >= 100 -> TRIP + flatten
    assert rm.enforce(9_850.0, broker) is True
    assert rm.is_tripped()
    assert broker.close_all_calls == 1

    # calling again while tripped does not double-flatten
    assert rm.enforce(9_850.0, broker) is True
    assert broker.close_all_calls == 1

    # persists across "restart"
    rm2 = RiskManager(cfg, state_dir=tmp_path)
    assert rm2.is_tripped()

    # a NEW day does NOT auto-clear the kill switch
    rm2.start_session(9_850.0, now=datetime(2030, 6, 4, 10, 0, tzinfo=NY))
    assert rm2.is_tripped()

    # only reset() clears it
    rm2.reset()
    assert not rm2.is_tripped()
    assert not RiskManager(cfg, state_dir=tmp_path).is_tripped()


def test_clamp_notional_and_stop_and_eod():
    cfg = make_config(stop_loss_pct=0.02, eod_flat=True)
    rm = RiskManager(cfg, state_dir=None)

    assert rm.clamp_notional(5_000) == 1_000  # capped at max_position_notional
    assert rm.clamp_notional(250) == 250

    assert rm.stop_loss_hit(entry_price=100.0, current_price=97.0) is True   # -3% < -2%
    assert rm.stop_loss_hit(entry_price=100.0, current_price=99.0) is False  # -1%

    close = datetime(2030, 6, 3, 20, 0, tzinfo=timezone.utc)
    assert rm.should_eod_flat(close, now=close - timedelta(minutes=3)) is True   # within 5 min
    assert rm.should_eod_flat(close, now=close - timedelta(minutes=30)) is False


# -- runner-level: HALTS + FLATTENS + refuses to trade ------------------------
def test_runner_halts_and_flattens_on_kill_switch(tmp_path):
    cfg = make_config(max_daily_loss=100.0)
    broker = FakeBroker(start_equity=10_000.0, cycle_equity=9_700.0, pos=1.0)
    runner = LiveRunner(cfg, state_dir=tmp_path, broker=broker, feed=FakeFeed(_tiny_bars()))

    runner.run(max_iterations=1, poll_seconds=0.0)

    assert runner.stats.killswitch_tripped is True   # runner saw the trip
    assert broker.close_all_calls >= 1               # flattened
    assert broker.buy_calls == 0                      # refused to trade
    # tripped state persisted
    assert RiskManager(cfg, state_dir=tmp_path).is_tripped()


def test_runner_closes_orphan_position_on_switch(tmp_path):
    """After switching `symbol`, the runner closes the old (orphan) position so
    nothing is left unmanaged."""
    cfg = make_config()  # symbol = SPY
    broker = FakeBroker(is_open=True, orphans=[("QQQ", 3.0)])  # holding a non-SPY position
    runner = LiveRunner(cfg, state_dir=tmp_path, broker=broker, feed=FakeFeed(_tiny_bars()))
    runner.run(max_iterations=1, poll_seconds=0.0)
    assert "QQQ" in broker.closed_symbols  # orphan was closed


def test_runner_session_mode_flattens_at_end(tmp_path):
    """until_close (full-day) session mode: runs while open and, with eod_flat
    on, flattens any residual position when the session ends."""
    cfg = make_config(max_daily_loss=100.0, eod_flat=True)
    broker = FakeBroker(start_equity=100_000.0, cycle_equity=100_000.0, pos=5.0)
    runner = LiveRunner(cfg, state_dir=tmp_path, broker=broker, feed=FakeFeed(_tiny_bars()))

    # one cycle (market open), then max_iterations ends the session
    runner.run(max_iterations=1, until_close=True)

    assert runner.stats.iterations == 1
    assert broker.close_all_calls >= 1   # session-end eod_flat flattened the position
