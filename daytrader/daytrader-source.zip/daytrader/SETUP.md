# daytrader — Setup & Operator Guide

A plain-language guide to running the bot. No prior trading-bot experience
assumed. Read the short **Risk reminder** at the bottom before you do anything
with real money.

> **What this is:** a small day-trading bot that runs in four modes —
> `backtest`, `select`, **`paper`** (the default), and `live`. In paper mode it
> pulls real-time data and places *simulated* orders through Alpaca's paper
> account, so you can watch the whole machine work with **zero financial risk**.

---

## 0. The correct first run (do these in order)

```bash
python -m venv venv
# activate it:
#   Windows (PowerShell):  venv\Scripts\Activate.ps1
#   Windows (cmd):         venv\Scripts\activate.bat
#   macOS/Linux:           source venv/bin/activate
pip install -r requirements.txt
# copy the env template and paste your Alpaca PAPER keys into .env:
#   Windows: copy .env.example .env
#   mac/lin: cp .env.example .env
python scripts/preflight.py          # fix any [FAIL] before continuing
python scripts/run_selection.py --source yfinance --resolution 1Day --start 2018-01-01   # optional research (no keys)
python scripts/run_live.py           # during market hours: watch it trade (paper)
```

Everything below explains each of these steps in detail.

---

## 1. Prerequisites — Python 3.11+

Check your version:

```bash
python --version
```

You need **3.11 or newer** (3.12 is a great choice). If you don't have it, get
it from [python.org/downloads](https://www.python.org/downloads/) (on Windows,
tick "Add Python to PATH" in the installer).

## 2. Environment — virtual environment + dependencies

A virtual environment keeps this project's packages separate from the rest of
your system.

```bash
python -m venv venv
```

Activate it (you'll do this every time you open a new terminal for the project):

- **Windows PowerShell:** `venv\Scripts\Activate.ps1`
  (if blocked: `Set-ExecutionPolicy -Scope Process RemoteSigned` then retry)
- **Windows cmd:** `venv\Scripts\activate.bat`
- **macOS / Linux:** `source venv/bin/activate`

Then install everything:

```bash
pip install -r requirements.txt
```

## 3. Alpaca paper keys (needed for paper mode — the default)

Paper mode places simulated orders through Alpaca and needs **free** keys:

1. Make a free account at [alpaca.markets](https://alpaca.markets).
2. Switch to the **Paper** account view (there's a paper/live toggle in the
   dashboard). Paper and live have **different** keys — use the paper ones.
3. Generate an API key. You'll get an **API Key ID** and a **Secret Key**.
4. Copy the template and paste your keys:
   ```bash
   copy .env.example .env      # Windows   (mac/linux: cp .env.example .env)
   ```
   Then edit `.env`:
   ```
   ALPACA_API_KEY=PK............
   ALPACA_SECRET_KEY=............
   ```
   **Never commit `.env`** — it's already git-ignored.

You do **not** need separate paper/live URLs. The code picks the right endpoint
from `mode` in `config.yaml` (`paper=True/False` under the hood).

## 4. Offline research (no keys required)

You can backtest and rank strategies with **zero keys** using `yfinance` daily
data:

```bash
python scripts/run_backtest.py  --strategy ma_crossover --source yfinance --resolution 1Day --start 2018-01-01
python scripts/run_selection.py --source yfinance --resolution 1Day --start 2018-01-01
```

- `run_backtest.py` writes an equity-curve PNG to `reports/` comparing your
  strategy against **buy-and-hold**, with trading costs modeled.
- `run_selection.py` ranks every candidate out-of-sample and either promotes a
  winner into `active_strategy.json` or prints **"NO EDGE FOUND"** (see step 9).

> Intraday history (`5Min`, `1Min`) needs Alpaca keys — `yfinance` intraday is
> unreliable and only covers a few recent weeks. Use `1Day` for key-free study.

## 5. Start the bot in paper mode

During US market hours (9:30–16:00 ET, weekdays):

```bash
python scripts/run_live.py
```

What you'll see, on each closed bar:

- the market clock (open/closed, next open/close),
- your session baseline equity and kill-switch status,
- the active strategy it loaded (from `active_strategy.json`),
- the bar it saw, the target position, your current position, and running P&L,
- any order it submits.

Logs stream to your terminal **and** append to `reports/live_YYYYMMDD.log`.
Stop any time with **Ctrl-C**.

Handy flags:

- `python scripts/run_live.py --iterations 3` — run 3 cycles then stop (good for
  a quick look).
- On the **very first** bar it can already act, because it **backfills** the
  warm-up bars a strategy needs on startup.

## 6. Change the strategy (two ways)

**A) Manually — takes effect on the next cycle, no restart:**

```bash
python scripts/set_strategy.py ma_crossover --params '{"fast":9,"slow":21}'
python scripts/set_strategy.py rsi_reversion --set period=14 --set oversold=25 --set exit_level=55
python scripts/set_strategy.py buy_and_hold
```

This rewrites `active_strategy.json`. The running bot re-reads that file at the
top of every loop, so your change is picked up on the **next bar** — no restart.

**B) Automatically — let the selector pick:**

```bash
python scripts/run_selection.py
```

It ranks all candidates out-of-sample and, **only if** a strategy beats
buy-and-hold, writes the winner into `active_strategy.json`. If none beats the
benchmark it prints **"NO EDGE FOUND"** and changes nothing.

**`auto_reselect`** (in `config.yaml`): when `true`, the idea is to periodically
re-run selection and **only** promote a new strategy if it beats **both** the
current one **and** buy-and-hold out-of-sample (this prevents thrashing between
mediocre strategies). Every switch is logged. Leave it `false` unless you want
that behavior.

> **Resolution coherence:** `bar_resolution` applies to *all* modes. Select on
> the same resolution you trade — never rank on `1Day` and trade on `5Min`.
> Strategy params are in **bars, not minutes**: `fast: 9` is 9 days on `1Day`
> but 9×5 = 45 minutes on `5Min`.

## 7. Configure risk (`risk:` in `config.yaml`)

| Field | Plain English |
|---|---|
| `max_daily_loss` | Dollars. If your session is down this much, the **kill switch** trips: it flattens everything and **halts trading**. Cannot be disabled — only the number is yours to set. |
| `max_position_notional` | Dollars of exposure per position. The bot sizes with **notional** (dollar) orders and never goes above this. |
| `stop_loss_pct` | Optional per-trade stop, e.g. `0.02` = exit if the position falls 2% from entry. `null` = off. |
| `eod_flat` | `true` closes everything a few minutes before the close, so nothing is held overnight (true day trading). |

**How the kill switch behaves (important):**

- At each market open it records your **starting equity** for the day.
- If `starting_equity − current_equity ≥ max_daily_loss`, it **flattens and
  stops**, and writes a `tripped` flag to `state/`.
- The flag **persists across restarts** and does **not** clear the next day. You
  must acknowledge it yourself:
  ```bash
  python scripts/reset_killswitch.py
  ```
- While tripped, the bot refuses to trade (and re-flattens anything it finds).

## 8. Going live (real money) — your decision

Two changes in `config.yaml`, and only when paper has genuinely convinced you:

```yaml
mode: "live"
i_understand_live_risk: true
```

If `i_understand_live_risk` is not `true`, live mode **refuses to start** with a
clear message. What changes when you flip these: **real orders** hit your
**real Alpaca account** and move **real money**. Everything else — the kill
switch, position caps, strategy-swapping — behaves exactly as it did in paper.

Then re-run preflight (it will check the **live** endpoint) and start small:

```bash
python scripts/preflight.py
python scripts/run_live.py
```

> **Pattern Day Trader (PDT) rule (US):** on a **margin** account, making 4+ day
> trades within 5 business days flags you as a Pattern Day Trader and generally
> requires maintaining **~$25,000** equity. Know this before trading intraday
> with real money. This is your call to make.

## 9. Read the results (what the numbers mean)

- **Total return / CAGR** — how much you made overall / annualized.
- **Sharpe ratio** — return per unit of wobble (risk). Higher is smoother.
  Roughly: <1 unremarkable, 1–2 decent, >2 strong — *for the sample tested*.
- **Max drawdown** — the worst peak-to-trough drop. `-30%` means at some point
  you were down 30% from a high. Small is good.
- **Beat buy-and-hold OOS** — the only test that matters here. "OOS" =
  out-of-sample = a held-out slice of history the strategy wasn't chosen on. If
  a strategy can't beat simply **holding** the asset out-of-sample after costs,
  it prints **"NO EDGE FOUND"** and promotes nothing. That is a *valid, honest*
  result — most simple strategies don't beat buy-and-hold.

> A good backtest is **not** a prediction. Out-of-sample outperformance only
> filters out obvious overfitting. It is not evidence of future profit.

## 10. Stop / recover

- **Stop the bot:** press **Ctrl-C**. In paper, open positions are simply left
  as they are (turn on `eod_flat` if you don't want anything held).
- **Kill switch tripped?** That means your daily loss limit was hit; the bot
  flattened and halted. Check `reports/live_*.log` for the reason, then:
  ```bash
  python scripts/reset_killswitch.py
  ```
  Confirm your broker positions look right before restarting.

## 11. Troubleshooting

| Symptom | Likely cause & fix |
|---|---|
| `MISSING ALPACA KEYS` | No `.env`, or keys still say `your_key_here`. Copy `.env.example` → `.env` and paste your **paper** keys. |
| `REFUSING TO START in live mode` | You set `mode: live` but not `i_understand_live_risk: true`. Set both, or go back to paper. |
| No data / "only N bars loaded" | Widen the date range, or switch to `bar_resolution: "1Day"`. Free Alpaca intraday (IEX) is thin. |
| It never places a trade | Often it's simply **flat** by design (signal = 0), or the **market is closed**, or notional orders are being tried outside regular hours (they're regular-hours only). Check the log line for `target=` and the market clock. |
| Empty / sparse intraday bars | Normal on the free **IEX** feed. The bot logs the gap and continues; consider `1Day`. |
| Order rejected | Usually market closed, or a fractional/notional order attempted outside regular hours. Trade during 9:30–16:00 ET. |
| `preflight` shows FAILs | Fix each one it names before trading. It exits non-zero if anything fails. |

### Free data limitation (read this)

The free Alpaca plan only includes the **IEX** feed — about **2.5%** of US
equity volume. Intraday bars (`5Min`, `1Min`) can therefore be **sparse or
gappy**. SPY is liquid enough to be usable; thinner symbols are worse. The full
consolidated **SIP** feed (100% of volume) is a **paid** subscription and is
what production-grade intraday trading needs.

**Low-friction fallback:** set `bar_resolution: "1Day"`. Daily bars are clean on
the free feed. Because resolution is config-driven, the whole system stays
coherent — you just make **once-a-day** decisions (that's swing trading, not
intraday). This is the recommended way to explore without paying for data.

## 12. Risk reminder

**Not financial advice. Risk only money you can afford to lose. Automating a
losing strategy just loses money faster.** Paper-trade until you genuinely
understand what the bot does, keep the kill switch on, and treat every backtest
as a sanity check — never a promise.
